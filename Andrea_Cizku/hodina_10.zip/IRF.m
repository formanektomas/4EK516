N=10000;
x0=0.2;
e=-1;
h=7;
s=3;

eps=0.1*randn(s+h,N);
eps(1:s-1,:)=0;
eps(s,:)=e;

x(1:s-1,:)=x0*ones(s-1,N);
x(s,:)=(x0+e)*ones(1,N);
for t=s+1:s+h
    x(t,:)=tanh(0.9*x(t-1,:)+eps(t,:));
end

for t=1:s+h
    x_hat(t)=mean(x(t,:));
    upper_bound(t)=prctile(x(t,:),95);
    lower_bound(t)=prctile(x(t,:),05);
end

plot(x_hat)
hold on
plot(upper_bound,'r')
plot(lower_bound,'r')
grid on





















    
    