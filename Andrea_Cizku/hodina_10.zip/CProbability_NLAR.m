
%% ADVANCED ECONOMETRICS
%
%  CONDITIONAL PROBABILITY OF NLAR(1)
%
%  Description: 
%  This code snippet shows how to numerically calculate the conditional
%  probability of a certain event given an NLAR(1) model.
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

    N = 10000; % Set number of draws

%% 2. Parameter Values

    x_T = 0.2; % Set value of x_T

%% 3. Generate Innovations
    
    eps_T1 = 0.1*randn(1,N); % Generate N values of epsilon_T+1

%% 4. Calculate N values of x_T+h

    x_T1 = tanh(0.9*x_T + eps_T1); 

        
%% 5. Calculate P(x_T+1>0.4)
   
    P04 = (1/N)*sum(x_T1>0.4);
    
%% 6. Print result

    P04 
 

