%-------------------------- Time Varying Parameter model (TVP) --------------------------


%------------------------------------- Nacteni dat --------------------------------------
%Import dat do Matlabu:
data=readtable('DATA_TVP.txt','Delimiter','space');
data.Quarter_Index=datetime(data.Quarter_Index,'InputFormat','yyyyQQQ');
data.Quarter_Index.Format='yyyy.QQQ';

%sloupec 1: Quarter_Index 1959Q3--1985Q4
%        2: m1growth===ctvrtletni tempo rustu menoveho agregatu M1 (v %)
%        3: dint_lag=zpozdena hodnota zmeny urokove sazby (3-mesicnich Treasury-bill)
%        4: inf_lag==zpozdena hodnota inflace
%        5: surp_lag==zpozdena hodnota cyklicke slozky rozpoctoveho prebytku
%        6: m1growth_lag==zpozdena hodnota promenne m1growth

qtr_idx=data.Quarter_Index;
data=data{:,2:6};  %diky pouziti zavorek {} bude odted "data" matice a ne tabulka
T=size(data,1);  %pocet pozorovani

y=data(:,1);X=[ones(T,1) data(:,2:5)];
%y...vektor vysvetlovane promenne
%X...matice vysvetlujicich promennych
%m1growth = intcpt + dint_lag + inf_lag +  surp_lag + m1growth_lag


%-------------------------------- Inicializace parametru ---------------------------------		
%Inicializace pocatecnich hodnot parametru:
pr_1=0.5;pr_2=0.1;pr_3=0.1;
pr_4=0.1;pr_5=0.1;pr_6=0.1;
PRMTR_IN=[pr_1;pr_2;pr_3;pr_4;pr_5;pr_6];
%1. odhadovany parametr: SIG_E...smerodatna odchylka nahodne chyby v measurement rovnici
%2.-6. odhadovany parametr: SIG_1 až SIG_5...
%...smerodatne odchylky náhodnych chyb v prechodove rovnici 
%(prechodova rovnice v tomto modelu popisuje dynamiku v case se menicich parametru)
	
%------------------------------ Maximalne verohodny odhad -------------------------------	
START=11;   
%Globalni proměnná START je pouzita pri vypoctu verohodnostni funkce, ktera je pocitana
%m-funkci LIK_FCN. Promenna START ma pouze za ucel prvnich 10 pozorovani vynechat a 
%nezahrnout je do vypoctu funkce verohodnosti. Prvnich 10 pozorovani se vynechava i pri
%vypisovani vysledku odhadu nepozorovatelnych promennych pomoci Kalmanova filtru, coz
%je realizovano funkci FILTER.
f=@(PRMTR_IN) LIK_FCN(PRMTR_IN,y,X,START);
[xout,fout,~,~,~,hess]=fminunc(f,PRMTR_IN);
%xout...odhad parametru
%fout...zaporna hodnota logaritmované funkce verohodnosti
%hess...hessova matice druhych parcialnich derivaci
PRM_FNL=xout; 

%Kovariancni matice odhadnutych parametru:
cov=inv(hess);
SD_fnl =sqrt(diag(cov)); %smerodatne chyby odhadnutych parametru

%Vypis vysledku ekonometrickeho odhadu parametru na obrazovku:
disp(['Hodnota verohodnostni funkce je: ' num2str(-fout)]) 
disp(['Odhadnute parametry: ' num2str(PRM_FNL')])
disp(['Smerodatne chyby odhadnutych parametru: ' num2str(SD_fnl')])

%-------------- Odhad nepozorovatelnych promennych pomoci Kalmanova filtru -----------------
[inov,tvp_coef]=FILTER(PRM_FNL,y,X,START);
%Funkce FILTER realizuje Kalmanův filtr.
%inov je matice obsahující:
%   v 1. sloupci: chyba predikce pozorovatelne promenne (tzv. inovace)
%   v 2. sloupci: rozptyl teto chyby predikce
%   Matice inov ma ovsem mene radku nez kolik je pozorovani, nebot prvnich START-1
%   radku je vynechano z inicializacnich duvodu.
%tvp_coef je matice majici stejny pocet radku jako matice inov
%tvp_coef ma 5 sloupcu, ve kterych jsou predikce 5-ti nepozorovatelnych
%promennych, kterymi v tomto modelu jsou time-varying parametry beta0t,...,beta4t

%Graficke zobrazeni vysledku ziskanych Kalmanovym filtrem:
figure(1);
subplot(2,2,1);
xindex=qtr_idx(START:length(qtr_idx));
plot(xindex, inov(:,1));  %v 1. sloupci matice inov je chyba predikce pozorovatelne promenne
xlabel('cas')
title('chyba predikce')

subplot(2,2,2);
plot(xindex, inov(:,2));  %2. sloupec matice inov obsahuje rozptyl chyby predikce pozorovatelne promenne
xlabel('cas')
title('rozptyl chyby predikce')

subplot(2,2,3);
plot(xindex,tvp_coef(:,1));
%1. sloupec matice tvp_coef obsahuje predikce prvni nepozorovatelne promenne
%   spoctene Kalmanovým filtrem, pricemz prvni nepozorovatelnou promennou v nasem
%   modelu je time-varying parametr beta0t
xlabel('cas')
title('beta0t')

subplot(2,2,4);
plot(xindex,tvp_coef(:,2));
xlabel('cas')
title('beta1t')

%Druhý grafický panel se zbývajícími grafy:
figure(2);
subplot(2,2,1);
plot(xindex,tvp_coef(:,3));
xlabel('cas')
title('beta2t')

subplot(2,2,2);
plot(xindex,tvp_coef(:,4));
xlabel('cas')
title('beta3t')

subplot(2,2,3);
plot(xindex,tvp_coef(:,5));
xlabel('cas')
title('beta4t')
