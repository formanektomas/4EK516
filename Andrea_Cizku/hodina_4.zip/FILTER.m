function X_MAT=FILTER(PRMTR1,z,START);
%Toto implementuje Kalmanuv filtr.
%Tato implementace je prakticky totozna s implementaci predesle funkce LIK_FCN, a to
%vcetne vstupnich argumentu teto funkce.
%V 1. sloupci matice X_MAT: odhad trendove slozky
%V 2. sloupci matice X_MAT: odhad tempa rustu trendove slozky
%V 3. sloupci matice X_MAT: odhad cyklicke slozky

  
%(Zpetná) transformace parametrů:
PRMTR=TRANSFORM(PRMTR1);

%Parametry a matice modelu sestaveneho v Kimově knize na str. 38 a 39:
sigma1=PRMTR(1,1);  %smerodatna odch. nahodne chyby eps1 v cyklicke slozce
sigma2=PRMTR(2,1);  %smerodatna odch. nahodne chyby eps2 v trendove slozce
sigma3=PRMTR(3,1);  %smerodatna odch. nahodne chyby eps3
phi1=PRMTR(4,1);    %auroregresní parametry v cyklické AR(2) složce
phi2=PRMTR(5,1);    %auroregresní parametry v cyklické AR(2) složce

A=[1  1  0     0;
   0  1  0     0;
   0  0  phi1  phi2;
   0  0  1     0];

D=[1 0 1 0];

COV_UU = zeros(4,4);
COV_UU(1,1)=sigma2^2; COV_UU(2,2)=sigma3^2;  COV_UU(3,3)=sigma1^2;

COV_VV = 0;

%Inicializace Kalmanova filtru:
x_LL=zeros(4,1);      
P_LL=eye(4)*100;         

%Kalmanuv filtr:
J=1;
n=length(z);  %n...pocet pozorovani
X_MAT=zeros(n,3);
while J<=n
  %predikcni rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovaci rovnice Kalmanova filtru:
  F_TL=D*P_TL*D'+COV_VV;
  K_T=P_TL*D'*inv(F_TL);
  z_TL=D*x_TL;
  
  x_TT=x_TL+K_T*(z(J,1)-z_TL);
  P_TT=P_TL-K_T*D*P_TL;
  
  %Ulozeni vysledku:
  X_MAT(J,:)=[x_TT(1,1) x_TT(2,1) x_TT(3,1)];
  %Ctvrta slozka odhadnuteho stavoveho vektoru x_TT neni ukladana, nebot to je pouze 
  %zpozdena hodnota cyklu.
  %V 1. sloupci matice BETA_MAT: odhad trendove slozky
  %V 2. sloupci matice BETA_MAT: odhad tempa rustu trendove slozky
  %V 3. sloupci matice BETA_MAT: odhad cyklicke slozky
  
  %Priprava na dalsi iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    

%(ukladame do vystupni promenne az od START=21 z duvodu nejistoty v pocatecnich
% pozorovanich, jez je zpusobena inicializaci Kalmanova filtru)
X_MAT=X_MAT(START:n,:);

end  
