function [mat1,mat2] = FILTER(PRMTR,y,X,START);
%VYSTUPY:
%mat1 ... matice majici 2 sloupce:
%         v 1. sloupci je chyba predikce pozorovatelne promenne
%         v 2. sloupci je jeji rozptyl
%mat2 ... matice majici 5 sloupcu:
%         v i-tem sloupci je predikce i-te nepozorovatelne promenne 
%        (i-teho v case se meniciho parametru)
%VSTUPY:
%Matice vysvětlujících proměnných X a vektor vysvětlované proměnné y obsahují 
%pozorovatelná data.
%Proměnná START=11 má pouze za účel prvních 10 pozorování vynechat a 
%nezahrnout je do výpočtu funkce věrohodnosti.


%Parametry a matice modelu:
SIG_E=PRMTR(1,1);
SIG_1=PRMTR(2,1);
SIG_2=PRMTR(3,1);
SIG_3=PRMTR(4,1);
SIG_4=PRMTR(5,1);
SIG_5=PRMTR(6,1);

A=eye(5); %máme 5 nepozorovatelnych promennych (v case se menicich parametru)

COV_VV=SIG_E^2;

COV_UU=[SIG_1^2 0 0 0 0;
        0 SIG_2^2 0 0 0;
		0 0 SIG_3^2 0 0; 
		0 0 0 SIG_4^2 0;
		0 0 0 0 SIG_5^2];

%Inicializace Kalmanova filtru:
x_LL=zeros(5,1);      
P_LL=eye(5)*50;     

%Kalmanuv filtr:
J = 1;
n=length(y);
mat1=zeros(n,2);   %inicializace datove struktury pro ukladani vysledku
mat2=zeros(n,5);  %inicializace datove struktury pro ukladani vysledku
while J<=n
  DT=X(J,:); zT=y(J,:);
  
  %predikcni rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovaci rovnice Kalmanova filtru:
  F_TL=DT*P_TL*DT'+COV_VV;
  K_T=P_TL*DT'*inv(F_TL);
  z_TL=DT*x_TL;
  
  x_TT=x_TL+K_T*(zT-z_TL);
  P_TT=P_TL-K_T*DT*P_TL;
  
  %Ulozeni vysledku:
  mat1(J,:)=[zT-z_TL  F_TL];  %chyba predikce pozorovatelne promenne a jeji rozptyl
  mat2(J,:)=x_TL';            %predikce nepozorovatelnych promennych (v case se menicich parametru)
  
  %Priprava na dalsi iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end

mat1=mat1(START:n,:);
mat2=mat2(START:n,:);
