function [DATA_smoothed,x_smoothed,P_smoothed]=SMOOTHER(x,x_,P,P_,A); 

%--------------------------------- INFO -----------------------------------
%It is an implementation of the Kalman smoother.
%
%-------------------------------- INPUTS ----------------------------------
%1. x.....Column vector xtt estimated by Kalman filter is stored at the
%         position x(:,:,t)  
%   Note:Estimates xtt of state vectors xt are stored (and not state
%        vectors xt themselves as they are unobservable)
%2. x_....Prediction (column) vector xt_tminus1 estimated by Kalman  
%         filter is stored at the position x_(:,:,t)
%3. P.....Covariance matrix Pt calculated by Kalman filter is stored at 
%         the position P(:,:,t)
%4. P_....Covariance matrix Pt_tminus1 calculated by Kalman filter is 
%         stored at the position P_(:,:,t)
%5. A.....Matrix in the transition equation of the State Space Form used
%         used in the calculations of the Kalman smoother
%   
%------------------------------- OUTPUTS ----------------------------------
%1. x_smoothed...x_smoothed(:,:,t) contains smoothed state vector xtT 
%                obtained by Kalman smoother
%2. P_smoothed...P_smoothed(:,:,t) contains smoothed estimate of the 
%                covariance matrix PtT
%--------------------------------------------------------------------------




%OBTAINING RELEVANT SIZE:
T=size(x,3);  %number of observations
n=size(x,1);  %number of state variables


%CREATING THREE DIMENSIONAL ARRAY STRUCTURE FOR STORING RESULTS:
x_smoothed=zeros(n,1,T);
P_smoothed=zeros(n,n,T);


%INITIAL CONDITION FOR BACKWARD RECURSION:
x_smoothed(:,:,T)=x(:,:,T);
P_smoothed(:,:,T)=P(:,:,T);
 
  
for t=T-1:(-1):1
  %RETRIEVING RELEVANT MATRICES NEEDED FOR KALMAN SMOOTHER RECURSION:
  Pt_t=P(:,:,t);
  Ptplus1_t=P_(:,:,t+1);
  xt_t=x(:,:,t);
  xtplus1_t=x_(:,:,t+1);
  xtplus1_T=x_smoothed(:,:,t+1);
  Ptplus1_T=P_smoothed(:,:,t+1);
  
  
  %KALMAN SMOOTHER:
  J_t=Pt_t*A'*(inv(Ptplus1_t));
  xt_T = xt_t + J_t * (xtplus1_T-xtplus1_t);          
  Pt_T = Pt_t + J_t * (Ptplus1_T-Ptplus1_t) * J_t';   
    
  
  %STORING THE RESULTS:
  x_smoothed(:,:,t)=xt_T;
  P_smoothed(:,:,t)=Pt_T;  
end




%STORING SMOOTHED ESTIMATES OF TREND AND CYCLE:
%Note:
%1. x_smoothed(1,1,:) is the first item in the (Kalman smoothed) state 
%   vector: nt...trend component of real GDP
%2. Technically, x_smoothed(1,1,:) is not a vector, but a subset of a 
%   3-dimensional structure (which cannot be displayed by the function
%   plot in Matlab).
%3. Therefore, the function "reshape" is used to transform it into a
%   standard (column) vector:
logGDP_trend=reshape(x_smoothed(1,1,:),T,1);   
logGDP_growth=reshape(x_smoothed(2,1,:),T,1); 
logGDP_cycle=reshape(x_smoothed(3,1,:),T,1);   

DATA_smoothed=[logGDP_trend logGDP_growth logGDP_cycle];


