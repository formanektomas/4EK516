function c1=TRANSFORM(c0)
%c0...vektor transformovanych koeficientu
%c1...vektor puvodnich koeficientu, ktere tato funkce pocita
%Tyto vektory maji 5 slozek, pricemz:
% - prvni tri slozky jsou odhady rozptylu náhodných chyb
% - zbyle dva jsou autoregresní parametry v AR(2) procesu phi1 a phi2
%Nezapornost rozptylu u prvních tri slozek je zajistena exponencialni funkci.
%Stacionarita autoregresnich parametru phi1 a phi2 v AR(2) procesu je zajistena 
%transformaci:
%phi1 = psi1/(1+abs(psi1)) + psi2/(1+abs(psi2))
%phi2 = (-1) * psi1/(1+abs(psi1)) * psi2/(1+abs(psi2))

c1(1:3,1)=exp(-1*c0(1:3,1))/10;

z1=c0(4,1)./(1+abs(c0(4,1)));
z2=c0(5,1)./(1+abs(c0(5,1)));

c1(4,1)=z1+z2;
c1(5,1)= -1* z1*z2 ;



