%inicializace parametru
PRMTR_IN=[0.5;0.1;0.1;0.1;0.1;0.1];

START=11;

f=@(PRMTR_IN) LIK_FCN(PRMTR_IN,y,X,START)
[xout,fout,~,~,~,hess]=fminunc(f,PRMTR_IN);
%xout...odhad parametru
%fout...zaporna hodnota verohodnostni funkce
%hess...hessova matice druhych parcialnich derivaci

cov=inv(hess);
SD=sqrt(diag(cov));

%vypis vysledku ekonometrickeho odhadu:
disp(['Hodnota verohodnostni funkce: ' num2str(-fout)])
disp(['Odhadnute parametry: ' num2str(xout')])
disp(['Smerodatne chyby odhadnutych parametru: ' num2str(SD')])

%odhad TVP parametru:
[tvp_coef]=FILTER(xout,y,X,START);

plot(tvp_coef(:,1))
title('beta0t')
pause
plot(tvp_coef(:,2))
title('beta1t')
pause
plot(tvp_coef(:,3))
title('beta2t')
pause
plot(tvp_coef(:,4))
title('beta3t')
pause
plot(tvp_coef(:,5))
title('beta4t')

