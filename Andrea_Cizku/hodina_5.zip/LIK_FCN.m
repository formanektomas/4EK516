function VAL=LIK_FCN(PRMTR,y,X,START);


SIG_E=PRMTR(1,1);  
SIG_1=PRMTR(2,1);  
SIG_2=PRMTR(3,1);  
SIG_3=PRMTR(4,1);  
SIG_4=PRMTR(5,1);  
SIG_5=PRMTR(6,1);  

A=eye(5);

COV_UU = zeros(5,5);
COV_UU(1,1)=SIG_1^2; COV_UU(2,2)=SIG_2^2;  COV_UU(3,3)=SIG_3^2;    
COV_UU(4,4)=SIG_4^2; COV_UU(5,5)=SIG_5^2; 

COV_VV = SIG_E^2;

%Inicializace Kalmanova filtru:
x_LL=zeros(5,1);      
P_LL=eye(5)*100;         

%Kalmanuv filtr:
J=1;
n=length(y);  %n...pocet pozorovani
LIK_VEC=zeros(n,1);
while J<=n
  DT=X(J,:); zT=y(J,:);
    
  %predikcni rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovaci rovnice Kalmanova filtru:
  F_TL=DT*P_TL*DT'+COV_VV;
  K_T=P_TL*DT'*inv(F_TL);
  z_TL=DT*x_TL;
  inovace_T=zT-z_TL;
  
  x_TT=x_TL+K_T*(zT-z_TL);
  P_TT=P_TL-K_T*DT*P_TL;
  
  %J-ty scitanec verohodnostni funkce:
  k=1;
  LIK_VEC(J,1)=-0.5*(k*log(2*pi) + log(det(F_TL)) + inovace_T'*inv(F_TL)*inovace_T);
  
  
  %Priprava na dalsi iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    

%(ukladame do vystupni promenne az od START=21 z duvodu nejistoty v pocatecnich
% pozorovanich, jez je zpusobena inicializaci Kalmanova filtru)
VAL=-sum(LIK_VEC(START:n));

end  
