function VAL=LIK_FCN(PRMTR1,z,START);
%Pocita zapornou hodnotu logaritmovane verohodnostni funkce.
%Zaporna hodnota funkce verohodnosti je zde pouzita proto, abychom mohli najit minimum
%pomocí MATLABovske funkce "fminunc".
%Vektor vysvetlovane promenne z obsahuje pozorovatelna data.
%Promenna START=21 ma pouze za ucel prvnich 20 pozorovani vynechat a 
%nezahrnout je do vypoctu funkce verohodnosti.

%(Zpetná) transformace parametrů:
PRMTR=TRANSFORM(PRMTR1);

%Parametry a matice modelu sestaveneho v Kimově knize na str. 38 a 39:
sigma1=PRMTR(1,1);  %smerodatna odch. nahodne chyby eps1 v cyklicke slozce
sigma2=PRMTR(2,1);  %smerodatna odch. nahodne chyby eps2 v trendove slozce
sigma3=PRMTR(3,1);  %smerodatna odch. nahodne chyby eps3
phi1=PRMTR(4,1);    %auroregresní parametry v cyklické AR(2) složce
phi2=PRMTR(5,1);    %auroregresní parametry v cyklické AR(2) složce

A=[1  1  0     0;
   0  1  0     0;
   0  0  phi1  phi2;
   0  0  1     0];

D=[1 0 1 0];

COV_UU = zeros(4,4);
COV_UU(1,1)=sigma2^2; COV_UU(2,2)=sigma3^2;  COV_UU(3,3)=sigma1^2;

COV_VV = 0;

%Inicializace Kalmanova filtru:
x_LL=zeros(4,1);      
P_LL=eye(4)*100;         

%Kalmanuv filtr:
J=1;
n=length(z);  %n...pocet pozorovani
LIK_VEC=zeros(n,1);
while J<=n
  %predikcni rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovaci rovnice Kalmanova filtru:
  F_TL=D*P_TL*D'+COV_VV;
  K_T=P_TL*D'*inv(F_TL);
  z_TL=D*x_TL;
  inovace_T=z(J,1)-z_TL;
  
  x_TT=x_TL+K_T*inovace_T;
  P_TT=P_TL-K_T*D*P_TL;
  
  %J-ty scitanec verohodnostni funkce 
  k=length(z_TL); %pocet pozorovatelnych promennych
  LIK_VEC(J,1) = -0.5*(k*log(2*pi) + log(det(F_TL)) + inovace_T'*inv(F_TL)*inovace_T);
  
  %Priprava na dalsi iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    

%Vypocet zaporne hodnoty log verohodnostni funkce:
%(vypocet zacina az od START=21 z duvodu inicializace Kalmanova filtru)
VAL=-sum(LIK_VEC(START:n));