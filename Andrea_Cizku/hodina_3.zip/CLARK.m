%------------------------------------- INFO ----------------------------------------------
%Clarkuv (1987) model dekompozice HDP:
%Model:
%           y(t) = mu(t) + ksi(t)
%
%Cyklus:    ksi(t)= phi1*ksi(t-1) + phi2* ksi(t-2) + eps1(t),
%                                                  eps1(t) -- i.i.d. N(0,sigma1^2)
%
%Trend:     mu(t)= beta(t-1) + mu(t-1) + eps2(t),  eps2(t) -- i.i.d. N(0,sigma2^2)
%           beta(t) = beta(t-1) + eps3(t)          eps3(t) -- i.i.d. N(0,sigma3^2)
%----------------------------------------------------------------------------------------


%------------------------------------- Nacteni dat --------------------------------------
data=readtable('DATA.txt','Delimiter','space');
%tabulka "data" ma dva sloupce:
%1. sloupec "Dates" obsahuje datumy (zatim jako stringove promenne): 1947Q1-1995Q3
%(celkem 195 pozorovani)
%2. sloupec "GDP" obsahuje odpovídajici data o HDP

%Převod datumu v 1. sloupci ze stringu na typ "datetime":
data.Dates=datetime(data.Dates,'InputFormat','yyyyQQ');
data.Dates.Format='yyyyQQ';

y= log(data.GDP);   %yy...vysvetlovana pozorovatelna promenna
T=length(y);

%-------------------------------- Inicializace parametru ---------------------------------
PRMTR_IN=[2;2;2;2;1];
%sigma1=PRMTR_IN(1,1);  smerodatna odch. nahodne chyby eps1 v cyklicke slozce
%sigma2=PRMTR_IN(2,1);  smerodatna odch. nahodne chyby eps2 v trendove slozce
%sigma3=PRMTR_IN(3,1);  smerodatna odch. nahodne chyby eps3
%phi1=PRMTR_IN(4,1); auroregresni parametry v cyklicke AR(2) slozce
%phi2=PRMTR_IN(5,1); auroregresni parametry v cyklicke AR(2) slozce
%Poznamka:
%Parametry se v tomto programu transformuji funkci TRANSFORM.m, takze uvedene inicializacni
%hodnoty nejsou inicializacnimi hodnotami pro puvodní parametry, ale pro transformovane
%parametry.
%Ze zpusobu (zpetne) transformace m-funkci TRANSFORM plyne, ze inicializacní hodnoty pro 
%puvodní parametry (pri uvedene inicializaci transformovaných parametru) jsou:
%sigma1...exp(-2)/10=0.014
%sigma2...exp(-2)/10=0.014
%sigma3...exp(-2)/10=0.014
%phi1...2/(1+|2|) + 1/(1+|1|) = 2/3 + 1/2 = 7/6
%phi2...(-1)* (2/3) * (1/2) = -1/3



%------------------------------ Maximalne verohodny odhad -------------------------------
START=21;  
%Globalni promenna START je pouzita pri vypoctu verohodnostni funkce, ktera je pocitana
%m-funkci LIK_FCN. Promenna START ma pouze za účel prvních START-1 pozorovani vynechat a 
%nezahrnout je do vypoctu funkce verohodnosti. Prvnich START-1 pozorovani se vynechava i pri
%vypisovani vysledku odhadu nepozorovatelnych promennych pomoci Kalmanova filtru, coz
%je realizovano funkci FILTER.
f=@(PRMTR_IN) LIK_FCN(PRMTR_IN,y,START);
[xout,fout]=fminunc(f,PRMTR_IN);
%xout...odhad parametru
%fout...zaporná hodnota funkce verohodnosti

PRM_FNL=TRANSFORM(xout); 
%Funkce TRANSFORM.m transformuje parametry a zajistuje tak splneni apriornich
%pozadavku na odhadnute parametry.

%Vypis vysledku ekonometrickeho odhadu parametru na obrazovku:
disp(['Hodnota verohodnostni funkce je: ' num2str(-fout)]) 
disp(['Odhadnute parametry: ' num2str(PRM_FNL')])



%-------------- Odhad nepozorovatelnych promennych pomoci Kalmanova filtru -----------------
DATA_filtered = FILTER(xout,y,START);
%V 1. sloupci matice DATA_filtered: odhad trendove slozky
%V 2. sloupci matice DATA_filtered: odhad tempa rustu trendove slozky
%V 3. sloupci matice DATA_filtered: odhad cyklicke slozky

%Grafické zobrazeni vysledku ziskanych Kalmanovym filtrem:
figure(1);
plot(data.Dates(START:T),[y(START:T,1) DATA_filtered(:,1)]);
legend('GDP','odhad trendu')

figure(2);
plot(data.Dates(START:T),DATA_filtered(:,2));
legend('odhad tempa rustu trendove slozky')

figure(3);
plot(data.Dates(START:T),[DATA_filtered(:,3) zeros(size(DATA_filtered,1),1)]);
legend('odhad cyklu')