function y_hat=EXP_VYR(y,std_u,std_v)

n=length(y);
y_hat=zeros(n,1);
y_hat(1)=y(1);
q=std_v/std_u;
lambda=(1+sqrt(1+4*q^2)) / (1+sqrt(1+4*q^2)+2*q^2);
for t=2:n
    y_hat(t)=y_hat(t-1)+lambda*(y(t)-y_hat(t-1));
end    