function [x,K]=FILTER(z,std_u,std_v)

%z ... sloupcovy vektor s pozorovatelnymi promennymi z(t),t=1,2,..,n
%x ... sloupcovy vektor s filtrovanymi odhady x(t|t)

A=1; 

D=1;

COV_VV=std_v^2;
COV_UU=std_u^2;

x_LL=0;
P_LL=1000000;

J=1;
n=length(z);  %n...pocet pozorovan�
x=zeros(n,1);
while J<=n
  %predikcni rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovaci rovnice Kalmanova filtru:
  K_T=P_TL*D'*inv(D*P_TL*D'+COV_VV);
  z_TL=D*x_TL;
  x_TT=x_TL+K_T*(z(J,1)-z_TL);
  P_TT=P_TL-K_T*D*P_TL;
  
  %Ulozeni vysledku:
  x(J,1)=x_TT';
  K(J,1)=K_T;
  
  %Priprava na dalsi iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    

end


