function ODHAD(std_u,std_v)

[y,mi]=GENDATA(std_u,std_v);
[x,K]=FILTER(y,std_u,std_v);
%x...odhad trendove slozky mi(t), t=1,...,n
%K...sloupcovy vektor skalarnich hodnot K(t), t=1,...,n

y_hat=EXP_VYR(y,std_u,std_v);

%zobrazeni konvergence nasich vah
subplot (2,2,1)
plot(K)

%zobrazeni skutecneho mi(t) a jeho odhadu
subplot (2,2,2)
n=length(y);
plot(1:n,mi,'r',1:n,x,'g',1:n,y_hat,'b')
legend('skutecne mi','odhad filtr','exp. vyr.','Location','southeast')
hold off

%zobrazeni pozorovatelneho indikatoru y(t) a jeho exp. vyrovnani
subplot(2,2,3)
plot(1:n,y,'r',1:n,y_hat,'ko')
legend('pozorovane y','exp.vyr.','Location','southeast')
hold off
