function [y,mi]=GENDATA(std_u,std_v);
%Funkce generuje data modelu lokalniho linearniho trendu.


%pocet nagenerovanych pozorovani
n=1000;

%Inicializace struktury pro ukladani vysledku:
y=zeros(n,1);
mi=zeros(n,1);

%Inicializace vypoctu:
mi_L=0;

%Vypocet:
for J=1:n 
  %Generovani dat:
  mi_T=mi_L+normrnd(0,std_u);
  y_T=mi_T+normrnd(0,std_v);
  
  %Ulozeni vysledku:
  y(J,1)=y_T;
  mi(J,1)=mi_T;
  
  %Priprava na dalsi krok cyklu:
  mi_L=mi_T;  
end

end
