function ODHAD(std_u,std_v)

%Nacteni dat do tabulky:
data=readtable('data_all.txt');

%Prevod dat z datoveho typu 'tabulka' na vektory:
y=data.y;
mi=data.mi;

%Provedeni vypoctu Kalmanovym filtrem:
[x,K]=FILTER(y,std_u,std_v);
%x...odhad trendove slozky mi(t), t=1,2,...,n
%K...sloupcovy vektor v nasem pripade skalarnich hodnot K(t),t=1,2,..,n

%Exponencialni vyrovnavani:
y_hat=EXP_VYR(y,std_u,std_v);

%Grafick� zobrazen� konvergence K(t):
subplot(2,2,1)
plot(K(1:1000))

%Graficke zobrazeni skutecneho mi(t) a jeho odhadu:
subplot(2,2,2)
n=length(y);
plot(1:n,mi,'r',1:n,x,'g',1:n,y_hat,'b')
legend('skutecne mi','odhad filtr','exp. vyr.','Location','southeast')
hold off

%Graficke zobrazeni pozorovatelneho indikatoru y(t) a jeho exp. vyrovnani:
subplot(2,2,3)
plot(1:n,y,'r',1:n,y_hat,'ko')
legend('pozorovane y','exp. vyr.','Location','southeast')
hold off

end




