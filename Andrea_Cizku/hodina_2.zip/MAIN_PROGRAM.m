%Vygenerovani dat:
[y,beta,mi]=GENDATA;

%Provedeni vypoctu Kalmanovym filtrem:
x_MAT=FILTER(y);
%x_MAT(:,1)...odhad trendove slozky mi(t), t=1,2,...,n
%x_MAT(:,2)...odhad tempa rustu beta(t), t=1,2,...,n

%Graficke zobrazeni vysledku:
plot(x_MAT(:,2))
hold on
pause
plot(beta)


