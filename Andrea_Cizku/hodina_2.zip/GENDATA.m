function [y,beta,mi]=GENDATA;
%Funkce generuje data modelu lokalniho linearniho trendu.
%Rozptyly vsech nahodnych chyb jsou jednotkove.


%pocet nagenerovanych pozorovani
n=100;

%Inicializace struktury pro ukladani vysledku:
y=zeros(n,1);
beta=zeros(n,1);
mi=zeros(n,1);

%Inicializace vypoctu:
beta_L=0;
mi_L=0;

%Vypocet:
for J=1:n 
  %Generovani dat:
  beta_T=beta_L+normrnd(0,1);
  mi_T=beta_L+mi_L+normrnd(0,1);
  y_T=mi_T+normrnd(0,1);
  
  %Ulozeni vysledku:
  y(J,1)=y_T;
  beta(J,1)=beta_T;
  mi(J,1)=mi_T;
  
  %Priprava na dalsi krok cyklu:
  beta_L=beta_T;
  mi_L=mi_T;  
end

end
