function [x,K]=FILTER(z,std_u,std_v)

%z ... sloupcov� vektor s pozorovateln�mi prom�nn�mi z(t),t=1,2,..,n
%x ... sloupcov� vektor filtrovan�ch odhad� n�hodn� proch�zky mi(t),t=1,2,..,n
%K ... sloupcov� vektor v na�em p��pad� skal�rn�ch hodnot K(t),t=1,2,..,n

A=1; 

D=1;

COV_UU=std_u^2;
COV_VV=std_v^2;

x_LL=0;
P_LL=1000000;

J=1;
n=length(z);  %n...po�et pozorov�n�
x=zeros(n,1);
while J<=n
  %predik�n� rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovac� rovnice Kalmanova filtru:
  K_T=P_TL*D'*inv(D*P_TL*D'+COV_VV);
  z_TL=D*x_TL;
  x_TT=x_TL+K_T*(z(J,1)-z_TL);
  P_TT=P_TL-K_T*D*P_TL;
  
  %Ulo�en� v�sledk�:
  x(J,1)=x_TT;
  K(J,1)=K_T;
  
  %P��prava na dal�� iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    

end


