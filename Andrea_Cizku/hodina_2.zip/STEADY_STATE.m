function K=STEADY_STATE(q)

K = (1+sqrt(1+4*q^2)) / (1+sqrt(1+4*q^2)+2*q^2);

end