function [A,D,CovU,CovV]=VytvorMatice(Par,z);
 
%--------------------------------- INFO -----------------------------------
%Tato m-funkce opakovane vol� m-funkci VytvorMatice_t s cilem vytvorit 
%vsechny potrebne matice stavove prostoroveho modelu. 
%
%-------------------------------- VSTUPY ----------------------------------
%1.Par...Sloupcov� vektor parametru modelu. 
%2.z.....Data 
%
%-------------------------------- VYSTUPY ---------------------------------
%Matice stavove prostoroveho tvaru modelu jsou ukladany do trirozmerneho
%pole tak, ze tretim rozmerem je casovy index t, pricemz t=1,...,T.
%Napriklad matice At je ulozena v trirozmernem poli A na pozici A(:,:,t).
%--------------------------------------------------------------------------
 

 
% VYPOCET MATIC PRO CASOVY OKAMZIK t=1:
[A1,D1,CovU1,CovV1]=VytvorMatice_t(Par,z,1);
 
%URCENI ROZMERU POTREBNYCH PRO VYTVORENI DATOVE STRUKTURY:
[r n]=size(D1);
T=length(z); 
%r...pocet pozorovatelnych promennych
%n...pocet stavovych promennych
%T...pocet pozorovani 
      
%VYTVORENI DATOVE STRUKTURY PRO UKLADANI DALSICH VYSLEDKU:
A=zeros(n,n,T); D=zeros(r,n,T); 
CovU=zeros(n,n,T); CovV=zeros(r,r,T);
 
%ULOZENI VYSLEDKU:
A(:,:,1)=A1; D(:,:,1)=D1;
CovU(:,:,1)=CovU1;  CovV(:,:,1)=CovV1;  



for t=2:T    
    %VYPOCET MATIC PRO CASOVY OKAMZIK t:
    [At,Dt,CovUt,CovVt]=VytvorMatice_t(Par,z,t);
         
    %UKLADANI VYSLEDKU:
    A(:,:,t)=At; D(:,:,t)=Dt;
    CovU(:,:,t)=CovUt;  CovV(:,:,t)=CovVt;      
end; 
