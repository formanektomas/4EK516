function ParProstor=VytvorParProstor;
 
%--------------------------------- INFO -----------------------------------
%1. V tomto souboru je vymezen definicni obor jednotlivych parametru. Kazdy 
%   radek matice ParProstor se tyka jednoho konkretniho parametru. 
%2. NEzavadim predpoklad o tom, ze vsechny parametry jsou nezaporne. Neni-li 
%   na parametr ��dn� po�adavek, je ve 3. sloupci matice ParProstor hodnota 
%   -Inf a ve 4. sloupci hodnota Inf. Ma-li byt parametr napr. nezaporny, je 
%   ve 3. sloupci hodnota 0 a ve 4. sloupci hodnota Inf. V p��pad� pozadavku 
%   nalezeni do intervalu (0,K) je ve 3. sloupci uvedena hodnota 0 a ve 4. 
%   sloupci hodnota K, kde K>0. 
%3. U mnoha parametru je mozne a zadouci parametricky prostor "rozumne"
%   zmensit. Z parametrickeho prostoru se totiz budou nahodne generovat bo-
%   dy slouzici k inicializaci numericke iteracni procedury hledajici maxi-
%   mum verohodnostn� funkce. V 1. sloupci matice ParProstor je dolni 
%   mez a ve 2. sloupci horni mez teto podmnoziny parametrickeho prostoru. 
%4. Pro generovani bodu z parametrickeho prostoru jsou proto vyuzivany pou-
%   ze prvn� dva sloupce, zatimco 3. a 4. sloupec je vyuzit pro
%   transformace parametru, ktere jsou provadeny proto, aby ziskane odhady 
%   skutecne nalezely do intervalu, ktery je vymezenen 3. a 4. sloupcem
%   matice ParProstor.
%--------------------------------------------------------------------------
 
ParProstor=[0       5         0      5;      %1. a          
            0       10        0      10;     %2. b          
            0       0.01      0      0.01;]; %3. std_eta
