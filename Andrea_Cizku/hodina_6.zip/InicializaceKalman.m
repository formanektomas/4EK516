function [xnula,Pnula]=InicializaceKalman(Par,z);

%-------------------------------- VSTUPY ----------------------------------
%1.Par...Sloupcovy vektor parametru modelu. (v tomto konkretnim modelu neni
%        zapotrebi)
%2.z.....Data miry nezamestnanosti 
%
%-------------------------------- V�STUPY ---------------------------------
%1.xnula...inicializacni stavovy vektor pro Kalmanuv filtr
%2.Pnula...inicializacni kovariancn� matice chyb predikce pro algoritmus
%          Kalmanova filtru.
%--------------------------------------------------------------------------
  


xnula=[mean(z);
       1]; 
       
Pnula=[var(z)  0;
       0       0;];

