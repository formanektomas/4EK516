%------------------------------------- Nacteni dat --------------------------------------
data=readtable('DATA.txt','Delimiter','space');
%tabulka "data" ma dva sloupce:
%1. sloupec "time" obsahuje datumy (zatim jako stringove promenne): 1995m01-2014m04
%2. sloupec "mira_nezam" obsahuje data o mire nezamestnanosti v Eurozone

%Prevod datumu v 1. sloupci ze stringu na typ "datetime":
data.time=datetime(data.time,'InputFormat','yyyy-MM');
data.time.Format='yyyy-MM';

z=data.mira_nezam;   

%-------------- Volani globalni optimalizacni procedury -----------------
[OdhadPar,fmax]=GlobalFmaxuncV(z,20);

a=OdhadPar(1)
b=OdhadPar(2)
c=log((1/0.01)-1)+(b*0.0819)

%-------------- Zavislost pravdepodobnosti prechodu na ut -----------------
u=0:0.01:1;
p=1./(1+exp(a+b*u));
q=1./(1+exp(c-b*u));

figure(1);
plot(u,p)
title('p...pravdepodobnost nalezeni zamestnani')

figure(2);
plot(u,q)
title('q...pravdepodobnost ztraty zamestnani')