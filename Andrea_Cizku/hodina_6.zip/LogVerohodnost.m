function l=LogVerohodnost(Par,z);
 
%-------------------------------- VSTUPY ----------------------------------
%1.Par........Sloupcovy vektor parametru modelu. 
%2.z..........pozorovatelna data 
%
%------------------------------- VYSTUPY ----------------------------------
%l...logaritmus hodnoty verohodnostni funkce 
%
%--------------------------------- INFO -----------------------------------
%Na pocatku zdrojoveho kodu se provede inverzn� transformace s c�lem n�vratu 
%k puvodnim hodnot�m, nebot je zapotrebi zavolat funkci FILTER, ktera pred-
%poklada puvodni (a nikoli) transformovane hodnoty parametru. Vystupni ar-
%gumenty funkce FILTER (Zvlnka, invF_, detF_) jsou dosazeny do vzorce 
%pro vypocet verohodnostni funkce, pomoc� kter�ho je spo�tena hodnota loga-
%ritmovan� v�rohodnostn� funkce. 
%--------------------------------------------------------------------------
  
PuvPar=InvTransformace(Par); 
[x,x_,zvlnka,P,P_,F_,invF_,detF_]=FILTER(PuvPar,z);   
 
[n,n,T]=size(P);
[r,r,T]=size(F_);


suma=0;
for t=25:T   
    invF_TL=invF_(:,:,t);
    detF_TL=detF_(:,:,t);
    zvlnkaT=zvlnka(:,:,t);
    suma=suma+log(detF_TL)+zvlnkaT'*invF_TL*zvlnkaT;  
end;     
l=-0.5*T*r*log(2*pi)-0.5*suma;
