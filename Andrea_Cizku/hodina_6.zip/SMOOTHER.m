function [DATA_smoothed,x_smoothed,P_smoothed]=SMOOTHER(x,x_,P,P_,A);

%x...vektor xtt bude ulozen na pozici x(:,:,t)
%x_...vektor xt_tminus1 bude ulozen na pozici x_(:,:,t)
%P...matice Ptt bude ulozen na pozici P(:,:,t)
%P_...matice Pt_tminus1 bude ulozen na pozici P_(:,:,t)

%x_smoothed...vektor xtT bude ulozen na pozici x_smoothed(:,:,t)
%P_smoothed...matice PtT bude ulozena na pozici P_smoothed(:,:,t)

T=size(x,3);  %pocet pozorovani
n=size(x,1);  %pocet stavovych promennych

x_smoothed=zeros(n,1,T);
P_smoothed=zeros(n,n,T);

x_smoothed(:,:,T)=x(:,:,T);
P_smoothed(:,:,T)=P(:,:,T);

for t=T-1:(-1):1
    Pt_t=P(:,:,t);
    Ptplus1_t=P_(:,:,t+1);
    xt_t=x(:,:,t);
    xtplus1_t=x_(:,:,t+1);
    xtplus1_T=x_smoothed(:,:,t+1);
    Ptplus1_T=P_smoothed(:,:,t+1);
    
    J_t=Pt_t*A'*inv(Ptplus1_t);
    
    xt_T=xt_t+J_t*(xtplus1_T-xtplus1_t);
    Pt_T=Pt_t+J_t*(Ptplus1_T-Ptplus1_t)*J_t';
    
    x_smoothed(:,:,t)=xt_T;
    P_smoothed(:,:,t)=Pt_T;
end

logGDP_trend=reshape(x_smoothed(1,1,:),T,1);
logGDP_growth=reshape(x_smoothed(2,1,:),T,1);
logGDP_cycle=reshape(x_smoothed(3,1,:),T,1);

DATA_smoothed=[logGDP_trend  logGDP_growth  logGDP_cycle];



    
    
