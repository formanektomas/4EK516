function [OdhadPar,fmax]=GlobalFmaxuncV(z,N);
 
%--------------------------------- INFO -----------------------------------
%Cilem teto m-funkce je nalezt globalni maximum funkce verohodnosti. Reali-
%zovano je to tak, ze je generovano N nahodnych bodu z parametrickeho pros- 
%toru pomoci funkce GenBodPar, ze kterych je volana funkce FmaxuncV, jez ma 
%pouze lokalni charakter a jeji vysledky mohou proto byt ovlivneny iniciali-
%zaci. Vystupem teto funkce je nejlepsi z N nalezenych resen�. 
%
%-------------------------------- VSTUPY ----------------------------------
%1.z jsou pozorovatelna data 
%2.N je pocet nahodne generovanych bodu z parametrickeho prostoru.
%--------------------------------------------------------------------------
 
 
%INICIALIZACNI GENEROVANI BODU Z PARAMETRICKEHO PROSTORU:
disp('n...dosavadn� po�et vol�n� funkce fminunc'); n=1
Inicializace=GenBodPar;
[OdhadPar,fmax]=FmaxuncV(Inicializace,z)
 
for n=2:N
    %GENEROVANI n-TEHO BODU Z PARAMETRICKEHO PROSTORU:
    n  %vypis poradoveho cisla volani funkce fminunc
    Inicializace=GenBodPar;  
    %Poznamka:
    %Vektor Inicializace bude transformovan az m-funkci FmaxuncV.
    [OdhadPar_n,fmax_n]=FmaxuncV(Inicializace,z) 
        
    %ULOZENE DOSUD NEJLEPS�HO NALEZENEHO RESENI:
    if fmax_n>fmax
        fmax=fmax_n;
        OdhadPar=OdhadPar_n;
    end;   
end;
