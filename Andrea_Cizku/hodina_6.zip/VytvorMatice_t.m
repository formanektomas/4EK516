function [At,Dt,CovUt,CovVt]=VytvorMatice_t(Par,z,t);

%-------------------------------- VSTUPY ----------------------------------
%1. Par...Sloupcovy vektor parametru modelu. 
%2. z.....Data 
%         V tomto m-souboru slouzi k vypoctu matic modelu, nebot matice pa-
%         rametru jsou casove indexovany.
%3. t.....casov� index t=1,...,T.
%
%-------------------------------- VYSTUPY ---------------------------------
%1. Matice stavove prostoroveho tvaru modelu (pro casov� okamzik t):
%   x(t)=A(t-1)*x(t-1)+u(t), CovUt=E[u(t)*u(t)']
%   z(t)=Dt*x(t)+v(t),       CovVt=E[v(t)*v(t)']
%--------------------------------------------------------------------------



%NACTENI HODNOT VSECH PARAMETRU:
[a,b,c,std_eta]=VytvorNazvyPar(Par);

%STANOVENI MENICICH SE KOEFICIENTU POMOCI DAT:

%VYPOCET ptminus1, qtminus1:
ut=z(t); 

pt=1/(1+exp(a+b*ut));
qt=1/(1+exp(c-b*ut));



%--------------------------------------------------------------------------
%                             STANOVENI MATIC
%--------------------------------------------------------------------------

At=[1-pt-qt   qt;
    0         1;];

Dt=[1 0];

CovUt=diag([std_eta^2   0]);  
 
CovVt=0;
