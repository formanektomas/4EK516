function x_MAT=FILTER(z)

%z ... sloupcov� vektor s pozorovateln�mi prom�nn�mi z(t),t=1,2,..,n
%x_MAT ... matice rozm�ru (n x 2)

A=[1 1;
   0 1]; 

D=[1 0];

COV_VV=1;
COV_UU=eye(2);

x_LL=zeros(2,1);
P_LL=1000000*eye(2);

J=1;
n=length(z);  %n...po�et pozorov�n�
x_MAT=zeros(n,2);
while J<=n
  %predik�n� rovnice Kalmanova filtru:
  x_TL=A*x_LL;
  P_TL=A*P_LL*A'+COV_UU;
  
  %Filtrovac� rovnice Kalmanova filtru:
  K_T=P_TL*D'*inv(D*P_TL*D'+COV_VV);
  z_TL=D*x_TL;
  x_TT=x_TL+K_T*(z(J,1)-z_TL);
  P_TT=P_TL-K_T*D*P_TL;
  
  %Ulo�en� v�sledk�:
  x_MAT(J,:)=x_TT';
  
  %P��prava na dal�� iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    

end


