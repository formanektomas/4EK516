function GENDATA;
%Funkce generuje data modelu lokálního lineárního trendu.
%Rozptyly všech náhodných chyb jsou jednotkové.
%Vygenerovaná data se ukládají do textového souboru data.txt.


%počet nagenerovaných pozorování
n=100;

%Inicializace struktury pro ukládání výsledků:
y=zeros(n,1);
beta=zeros(n,1);
mi=zeros(n,1);

%Inicializace výpočtu:
beta_L=0;
mi_L=0;

%Výpočet:
for J=1:n 
  %Generování dat:
  beta_T=beta_L+normrnd(0,1);
  mi_T=beta_L+mi_L+normrnd(0,1);
  y_T=mi_T+normrnd(0,1);
  
  %Uložení výsledků:
  y(J,1)=y_T;
  beta(J,1)=beta_T;
  mi(J,1)=mi_T;
  
  %Příprava na další krok cyklu:
  beta_L=beta_T;
  mi_L=mi_T;  
end

%Uložení vygenerovaných dat do textového souboru:
DATA=table(y,beta,mi);
writetable(DATA,'data.txt')

end
