%Na�ten� dat do tabulky:
data=readtable('data_all.txt');

%P�evod dat z datov�ho typu 'tabulka' na vektory:
y=data.y;
beta=data.beta;
mi=data.mi;

%Proveden� v�po�tu Kalmanov�m filtrem:
x_MAT=FILTER(y);
%x_MAT(:,1)...odhad trendov� slo�ky mi(t), t=1,2,...,n
%x_MAT(:,2)...odhad tempa r�stu beta(t), t=1,2,...,n

%Grafick� zobrazen� v�sledk�:
plot(x_MAT(:,2))
hold on
pause
plot(beta)


