function Bod=GenBodPar;
 
%--------------------------------- INFO -----------------------------------
%Tato funkce nahodne vygeneruje jeden bod z parametrickeho prostoru, a to
%s vyuzitim rovnomerneho pravdepodobnostniho rozdeleni. Informace o para-
%metrickem prostoru je ziskana volanim funkce VytvorParProstor.
%--------------------------------------------------------------------------
 

ParProstor=VytvorParProstor;
n=size(ParProstor,1);
Bod=zeros(n,1);     

 
for i=1:n            %Generovani n�hodnych bodu z parametrickeho prostoru
    a=ParProstor(i,1);
    b=ParProstor(i,2);
    Bod(i)=a+(b-a)*rand(1);
end; 
