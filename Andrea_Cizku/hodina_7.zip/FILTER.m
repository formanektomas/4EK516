function [x,x_,zvlnka,P,P_,F_,invF_,detF_]=FILTER(Par,z);

%-------------------------------- VSTUPY ----------------------------------
%1.Par...Sloupcovy vektor parametru modelu. 
%2.z.....pozorovatelna data
%         
%------------------------------- V�STUPY ----------------------------------
%Vsechny vystupy jsou zde ukladany do tridimenzionalniho pole, pricemz
%treti dimenzi je casovy index t, ktery nabyva hodnot od 1 do T. 
%
%1. x........na pozici x(:,:,t) bude ulozen sloupcovy vektor xtt 
%   Poznamka:Ukladaji se vektory odhadu xtt, a nikoli stavove vektory xt,           
%            ktere nejsou pozorovatelne.
%2. x_.......na pozici x_(:,:,t) bude ulozen sloupcovy vektor xt_tminus1.
%3. zvlnka...na pozici zvlnka(:,:,t) bude ulo�en sloupcovy vektor 
%            zvlnkat=zt-zt_tminus1 s chybami predikce pozorovatelnych 
%            promennych.
%4. P........na pozici P(:,:,t) bude ulozena matice Pt.
%5. P_.......na pozici P_(:,:,t) bude ulozena matice Pt_tminus1.
%6. F_.......na pozici F_(:,:,t) bude matice 
%            Ft_tminus1=Dt*Pt_tminus1*Dt'+cov_vvt.
%--------------------------------------------------------------------------
   
%VYPOCET MATIC MODELU A INICIALIZACNICH MATIC PRO KALMANUV FILTR:
[A,D,CovU,CovV]=VytvorMatice(Par,z);      
[xnula,Pnula]=InicializaceKalman(Par,z);
x_LL=xnula;
P_LL=Pnula;
 
%URCENI POTREBNYCH ROZMERU:
[r,n,T]=size(D);
%r...pocet pozorovatelnych promennych
%n...pocet stavovych promennych
%T...pocet matic, ktere byly vyrobeny funkci VytvorMatice.
  
%PRIPRAVA STRUKTURY, DO KTERE BUDOU VYSLEDKY UKLADANY:
x=zeros(n,1,T);
x_=zeros(n,1,T);
zvlnka=zeros(r,1,T);
P=zeros(n,n,T);
P_=zeros(n,n,T);
F_=zeros(r,r,T);
invF_=zeros(r,r,T);
detF_=zeros(1,1,T);
 

%Kalmanuv filtr:
J=2;
while J<=T
  %VYPOCET POTREBNYCH MATIC:
  AL=A(:,:,J-1);
  DT=D(:,:,J);
  CovUT=CovU(:,:,J);    
  CovVT=CovV(:,:,J);
  
  %predikcni rovnice Kalmanova filtru:
  x_TL=AL*x_LL;
  P_TL=AL*P_LL*AL'+CovUT;
  
  %Filtrovaci rovnice Kalmanova filtru:
  F_TL=DT*P_TL*DT'+CovVT;
  K_T=P_TL*DT'*inv(F_TL);
  z_TL=DT*x_TL;
  zvlnkaT=z(J)-z_TL;
  
  x_TT=x_TL+K_T*zvlnkaT;
  P_TT=P_TL-K_T*DT*P_TL;
  
  %Ulozeni vsech vysledku:     
  x(:,:,J)=x_TT;
  x_(:,:,J)=x_TL;
  zvlnka(:,:,J)=zvlnkaT;
  P(:,:,J)=P_TT;
  P_(:,:,J)=P_TL;
  F_(:,:,J)=F_TL;
  invF_(:,:,J)=inv(F_TL);
  detF_(:,:,J)=det(F_TL);
  
  %Priprava na dalsi iteraci:
  x_LL=x_TT;
  P_LL=P_TT;
  J=J+1;
end    


end   
 
