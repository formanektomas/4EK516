function [OdhadPar,fmax]=FmaxuncV(Inicializace,z)
 
%--------------------------------- INFO -----------------------------------
%Cilem teto funkce je nalezt volne (nevazane) maximum funkce verohodnosti, 
%coz je realizovano tak, ze se preda zaporna verohodnostni funkce algoritmu 
%fminunc hledajici volne (nevazane) minimum funkce. Apriorni pozadavky na 
%meze parametru je nicmene zajisteno transformaci parametru.
% 
%-------------------------------- VSTUPY ----------------------------------
%1.Inicializace...Bod, ze ktereho je procedura fminunc spustena. Jedn� se o
%                 vektor parametru, kter� dosud nebyl transformovan.
%2.z..............pozorovatelna data 
%
%------------------------------- V�STUPY ----------------------------------
%1.OdhadPar...Bod nalezeneho maxima funkce verohodnosti algoritmem fminunc.
%             Jedna se o odhad vektoru puvodnich (a nikoli transformova-
%             nych) parametru.
%2.fmax.......Hodnota funkce v�rohodnosti v bode nalezeneho maxima.
%--------------------------------------------------------------------------
 
 
Inicializace=Transformace(Inicializace);
 
fce=@(Par) (-1)*LogVerohodnost(Par,z);      
[OdhadPar,fmin]=fminunc(fce,Inicializace); 
 
fmax=-fmin;
OdhadPar=InvTransformace(OdhadPar);
