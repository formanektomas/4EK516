function PuvPar=InvTransformace(Par)
 
%--------------------------------- INFO -----------------------------------
%Cilem teto m-funkce je provest inverzni transformaci a navratit se zpet 
%k puvodnim parametrum, ktere byly transformovany funkci Transformace.
%Podrobnejsi informace, viz. komentar k funkci Transformace.
%--------------------------------------------------------------------------
 
 
ParProstor=VytvorParProstor;
[m n]=size(ParProstor);
 
PuvPar=zeros(m,1);  
 
for i=1:m
  if (ParProstor(i,3)==-Inf) & (ParProstor(i,4)==Inf) %Neni-li na i-ty parametr kladena zadna podminka.                                                         
    PuvPar(i)=Par(i); 
  elseif ParProstor(i,4)==Inf                         %Je-li i-ty parametr omezen pouze zdola.                         
    D=ParProstor(i,3);  %D je dolni mez.
    PuvPar(i)=D+(Par(i))^2;                         
  elseif ParProstor(i,3)==-Inf                        %Je-li i-ty parametr omezen pouze shora. 
    H=ParProstor(i,4);  %H je horni mez.  
    PuvPar(i)=H-(Par(i))^2;
  else                                                %Je-li i-ty parametr omezen shora i zdola.
    H=ParProstor(i,4);
    D=ParProstor(i,3);
    PuvPar(i)=  ((D+H)/2)   +  ((H-D)/pi)*atan(Par(i))  ;  
  end;
end;  