function Par=Transformace(PuvPar)
 
%--------------------------------- INFO -----------------------------------
%1.Tato funkce provede transformaci s parametry s cilem zajistit si splneni
%  apriornich pozadavku na odhady parametru pri maximalizaci verohodnostni 
%  funkce pomoci metod hledajicich volny extrem (fminunc).
%2.Informaci o parametrickem prostoru (tj. o apriornich pozadavcich na pa-
%  rametry) je zde ziskana prikazem ParProstor=VytvorParProstor;.
%3.Napriklad transformace parametru, ktere po odhadu maji splnovat pouze  
%  podminku nezapornosti, spociva v tom, ze se odmocni. Zpetna transformace  
%  spocivajici v mocneni na druhou pak zajisti kyzenou nezapornost.
%--------------------------------------------------------------------------
  
 
ParProstor=VytvorParProstor;
[m n]=size(ParProstor);
 
Par=zeros(m,1);  
 
for i=1:m
  if (ParProstor(i,3)==-Inf) & (ParProstor(i,4)==Inf) %Neni-li na i-ty parametr kladena zadna podminka.                                                         
    Par(i)=PuvPar(i); 
  elseif ParProstor(i,4)==Inf                         %Je-li i-ty parametr omezen pouze zdola.                             
    D=ParProstor(i,3);  %D je dolni mez.
    Par(i)=sqrt(PuvPar(i)-D);                         
  elseif ParProstor(i,3)==-Inf                        %Je-li i-ty parametr omezen pouze shora. 
    H=ParProstor(i,4);  %H je horni mez.  
    Par(i)=sqrt(H-PuvPar(i));
  else                                                %Je-li i-ty parametr omezen shora i zdola.
    H=ParProstor(i,4);
    D=ParProstor(i,3);
    Par(i)=tan(  (pi/(H-D)) * (PuvPar(i)-(D+H)/2)   );  
  end;
end;  
