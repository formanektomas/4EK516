function [a,b,c,std_eta]=VytvorNazvyPar(Par);
     
 
k=1;
a=Par(k);         k=k+1;     
b=Par(k);         k=k+1; 
std_eta=Par(k);  

upruh=0.0819;
qpruh=0.01;
c=log((1/qpruh)-1)+(b*upruh);
       
