%-------------- Volani globalni optimalizacni procedury -----------------
[OdhadPar,fmax]=GlobalFmaxuncV(z,10);   %z jsou nactena data pro miru nezamestnanosti

a=OdhadPar(1)
b=OdhadPar(2)
c=log((1/0.01)-1)+(b*0.0819)

%-------------- Zavislost pravdepodobnosti prechodu na ut -----------------
u=0:0.01:1;
p=1./(1+exp(a+b*u));
q=1./(1+exp(c-b*u));

figure(1);
plot(u,p)
title('p...pravdepodobnost nalezeni zamestnani')

figure(2);
plot(u,q)
title('q...pravdepodobnost ztraty zamestnani')