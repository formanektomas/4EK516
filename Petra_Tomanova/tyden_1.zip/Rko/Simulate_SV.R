
## ADVANCED ECONOMETRICS
#
#  SIMULATE DATA FROM A STOCHASTIC VOLATILITY MODEL
#
#  Description: 
#  This code snippet shows how to simulate data from a 
#  stochastic volatility (SV) model given by
#
#  x(t) = exp(sig(t)) * eps(t)
#
#  sig(t+1) = a + b * sig(t) + v(t)
#
#  where eps ~ NID(0,sigma_eps^2)  and  v ~ NID(0,sigma_v^2)
#
#  Francisco Blasques 2016
#  Petra Tomanova 2020


## 0. Clean Workspace and Command Window

rm(list = ls())   # clear envirnment       

## 1. Setup

T = 1000  # sample size

## 2. Parameter Values

a = 0.1      # intercept parameter in update equation
b = 0.8     # autoregressive parameter in update equation
sigma_v = 0.05  # standard error of innovations in update equation
sigma_eps = 0.1  # standard error of innovations in observation equation
sig1 = a/(1-b) # define initial value for conditional log volatility

## 3. Generate Innovations

v = sigma_v*rnorm(T) # generate a vector of T random normal 
# variables with variance sigma_v^2

epsilon = sigma_eps*rnorm(T) # generate a vector of T random normal 
# variables with variance sigma_eps^2

## 4. Define Time Series Vector

sig = rep(0,T) # define vector of zeros of length T
x = rep(0,T) # define vector of zeros of length T

## 5. Define Initialization for Time Series

sig[1] = sig1

## 6. Generate Time Series

for (t in 1:T) { # start recursion from t=2 to t=T

  sig[t+1] = a + b * sig[t] + v[t] #update equation

  x[t] = exp(sig[t]) * epsilon[t] # observation equation

} # end recursion

## 7. Print Time Series in Command Window

df = data.frame(sig = exp(sig[1:T]), y = x)

## 8. Plot Data

par(mfrow=c(2, 1))
plot(x, type="l", lty=2)  # plot the time-series x in black
# draw next plot in same graph
plot(exp(sig), type="l", col = 'red')  # plot volatility sigma in red

library(reshape2)
library(ggplot2)

dfp = melt(df)
dfp$x = rep(1:T,2)

ggplot(dfp, aes(x = x, y = value)) + 
  geom_line(aes(linetype = variable, color = variable)) +
  theme(legend.position = "none", axis.title.x=element_blank(), axis.title.y=element_blank()) 







