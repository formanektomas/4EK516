
## ADVANCED ECONOMETRICS
#
#  SIMULATE DATA FROM AR(1)
#
#  Description: 
#  This code snippet shows how to simulate data from a Gaussian 
#  autoregressive model (AR) of order 1 given by:
#
#   x(t) = alpha + beta * x(t-1) + epsilon(t)
#
#  with NID(0,sigma^2) innovations {epsilon(t)}. 
#
#  Francisco Blasques 2016
#  Petra Tomanova 2020


## 0. Clean Workspace and Command Window

rm(list = ls())   # clear envirnment

## 1. Setup

T = 500  # sample size

## 2. Parameter Values

alpha = 0.2    # intercept parameter
beta = 0.9   # autoregressive parameter
sigma = 0.1  # standard error of innovations
x1 = alpha/(1-beta) # define initial value for time series x

## 3. Generate Innovations

epsilon = sigma*rnorm(T) # generate a vector of T random normal 
# variables with variance sigma^2

## 4. Define Time Series Vector

x = rep(0,T) # define vector of zeros of length T

## 5. Define Initialization for Time Series

x[1] = x1 

## 6. Generate Time Series

for (t in 2:T) { # start recursion from t=2 to t=T

  x[t] =  alpha + beta * x[t-1] + epsilon[t] # generate x(t) recursively

} # end recursion

## 7. Print Time Series in Command Window

x # display the values of x in the command window

## 8. Plot Data

par(mfrow=c(1, 2))
plot(x, type = 'l')
hist(x, breaks = 20)

library(ggplot2)
library(gridExtra)

df = data.frame(x = 1:T, y = x, s = 's1')

p1 = ggplot(df, aes(x = x, y = y)) + 
  geom_line(aes(color = s)) +
  theme(legend.position = "none", axis.title.x=element_blank(), axis.title.y=element_blank()) 

p2 = ggplot(df, aes(x = y)) + 
  geom_histogram(bins = 25) +
  theme(legend.position = "none", axis.title.x=element_blank(), axis.title.y=element_blank()) 

grid.arrange(p1,p2, nrow = 1)





