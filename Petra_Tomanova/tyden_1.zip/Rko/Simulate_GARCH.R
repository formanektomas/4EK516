
## ADVANCED ECONOMETRICS
#
#  SIMULATE DATA FROM GARCH(1,1) MODEL
#
#  Description: 
#  This code snippet shows how to simulate data from a generalized 
#  autoregressive conditional hetereoeskedasticity (GARCH) model given by:
#
#  x(t) = sqrt(sig(t)) * eps(t)
#
#  sig(t+1) = omega + alpha * x(t)^2 + beta * sig(t)
#
#  where eps ~ NID(0,1)
#
#  Francisco Blasques 2016
#  Petra Tomanova 2020


## 0. Clean Workspace and Command Window

rm(list = ls())   # clear envirnment     

## 1. Setup

T = 1000  # sample size

## 2. Parameter Values

omega = 0.1      # intercept parameter in update equation
alpha = 0.2     # OD parameter in update equation
beta =  0.7      # autoregressive parameter in update equation
sig1 = omega/(1-alpha-beta) # initial value for conditional volatility

## 3. Generate Innovations

epsilon = rnorm(T) # generate a vector of T random normal 
# variables with variance sigma_eps^2

## 4. Define Time Series Vector

sig = rep(0,T) # define vector of zeros of length T
x = rep(0,T) # define vector of zeros of length T

## 5. Define Initialization for Time Series

sig[1] = sig1

## 6. Generate Time Series

for (t in 1:T) { # start recursion from t=2 to t=T

  x[t] = sqrt(sig[t]) * epsilon[t] # observation equation

  sig[t+1] = omega + alpha * x[t]^2 + beta * sig[t] # update equation


} # end recursion

## 7. Print Time Series in Command Window

df = data.frame(sig = sqrt(sig[1:T]), y = x)

## 8. Plot Data

par(mfrow=c(1, 1))
plot(x, type="l", lty=2)  # plot the time-series x in black
# draw next plot in same graph
lines(sig, col = 'red')  # plot volatility sigma in red

library(reshape2)
library(ggplot2)
library(gridExtra)

dfp = melt(df)
dfp$x = rep(1:T,2)

ggplot(dfp, aes(x = x, y = value)) + 
  geom_line(aes(linetype = variable, color = variable)) +
  theme(legend.position = "none", axis.title.x=element_blank(), axis.title.y=element_blank()) 




