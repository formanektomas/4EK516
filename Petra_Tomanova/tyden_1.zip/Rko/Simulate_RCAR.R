
## ADVANCED ECONOMETRICS
#
#  SIMULATE DATA FROM RCAR(1)
#
#  Description: 
#  This code snippet shows how to simulate data from a Gaussian 
#  random coefficient autoregressive model (RCAR) of order 1
#  given by:
#
#   x(t) = alpha + b(t) * x(t-1) + epsilon(t)
#
#  with NID(0,sigma_eps^2) innovations {epsilon(t)}
#  and NID(beta,sigma_beta^2) random parameter {b(t)}.
#
#  Francisco Blasques 2016
#  Petra Tomanova 2020


## 0. Clean Workspace and Command Window

rm(list = ls())   # clear envirnment

## 1. Setup

T = 100  # sample size

## 2. Parameter Values

alpha = 1      # intercept parameter
beta = 0.8     # mean of random autoregressive parameter
sigma_b = 0.05  # standard error of innovations
sigma_eps = 0.1  # standard error of innovations
x1 = alpha/(1-beta) # define initial value for time series x

## 3. Generate Random Coefficient and Innovations

b = beta + sigma_b*rnorm(T) # generate a vector of T random normal 
# variables with mean beta and variance sigma^2

epsilon = sigma_eps*rnorm(T) # generate a vector of T random normal 
# variables with variance sigma^2

## 4. Define Time Series Vector

x = rep(0,T) # define vector of zeros of length T

## 5. Define Initialization for Time Series

x[1] = x1 

## 6. Generate Time Series

for (t in 2:T) { # start recursion from t=2 to t=T

  x[t] =  alpha + b[t] * x[t-1] + epsilon[t] # generate x(t) recursively

} # end recursion

## 7. Print Time Series in Command Window

x # display the values of x in the command window

## 8. Plot Data

par(mfrow=c(1, 1))
plot(x,type = 'l')  # plot the time-series x in black 'k'

library(ggplot2)

df = data.frame(x = 1:T, y = x, s = 's1')
ggplot(df, aes(x = x, y = y)) + 
  geom_line(aes(color = s)) +
  theme(legend.position = "none", axis.title.x=element_blank(), axis.title.y=element_blank()) 




