
%% ADVANCED ECONOMETRICS
%
%  SIMULATE DATA FROM GARCH(1,1) MODEL
%
%  Description: 
%  This code snippet shows how to simulate data from a generalized 
%  autoregressive conditional hetereoeskedasticity (GARCH) model given by:
%
%  x(t) = sqrt(sig(t)) * eps(t)
%
%  sig(t+1) = omega + alpha * x(t)^2 + beta * sig(t)
%
%  where eps ~ NID(0,1)
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

    T=10000;  % sample size

%% 2. Parameter Values

    omega = 0.1;      % intercept parameter in update equation
    alpha = 0.45;     % OD parameter in update equation
    beta =  0.0;  % autoregressive parameter in update equation
    sig1 = omega/(1-alpha-beta); % initial value for conditional volatility

%% 3. Generate Innovations

    epsilon = randn(T,1); % generate a vector of T random normal 
                                % variables with variance sigma_eps^2

%% 4. Define Time Series Vector

    sig = zeros(T,1); % define vector of zeros of length T
    x = zeros(T,1); % define vector of zeros of length T
    
%% 5. Define Initialization for Time Series

    sig(1) = sig1;

%% 6. Generate Time Series

    for t=1:T % start recursion from t=2 to t=T
       
       x(t) = sqrt(sig(t)) * epsilon(t); % observation equation
       
       sig(t+1) = omega + alpha * x(t)^2 + beta * sig(t); % update equation
        
        
    end % end recursion
    
%% 7. Print Time Series in Command Window

[x(1:T),sqrt(sig(1:T))] % display the values of x and volatility  
                         % side by side from t=1 to t=T

%% 8. Plot Data

figure(1)

subplot(2,1,1)    % plot goes on upper part of figure 1
plot(x(1:T),'k')  % plot the time-series x in black 'k'

subplot(2,1,2)           % plot goes on upper part of figure 1
plot(sqrt(sig(1:T)),'r')  % plot volatility sigma in red 'r' 




    

    
