
%% ADVANCED ECONOMETRICS
%
%  SIMULATE DATA FROM AR(1)
%
%  Description: 
%  This code snippet shows how to simulate data from a Gaussian 
%  autoregressive model (AR) of order 1 given by:
%
%   x(t) = alpha + beta * x(t-1) + epsilon(t)
%
%  with NID(0,sigma^2) innovations {epsilon(t)}. 
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

    T=500;  % sample size

%% 2. Parameter Values

    alpha = 0.0;    % intercept parameter
    beta = 0.9;   % autoregressive parameter
    sigma = 0.1;  % standard error of innovations
    x1 = alpha/(1-beta) % define initial value for time series x

%% 3. Generate Innovations

    epsilon = sigma*randn(T,1); % generate a vector of T random normal 
                                % variables with variance sigma^2

%% 4. Define Time Series Vector

    x = zeros(T,1); % define vector of zeros of length T
    
%% 5. Define Initialization for Time Series

    x(1) = x1; 

%% 6. Generate Time Series

    for t=2:T % start recursion from t=2 to t=T
        
       x(t) =  alpha + beta * x(t-1) + epsilon(t); % generate x(t) recursively
        
    end % end recursion
    
%% 7. Print Time Series in Command Window

x % display the values of x in the command window

%% 8. Plot Data

figure2 = figure(2);
set(figure2) 
subplot(1,3,1:2)
plot(x,'r')  % plot the time-series x in black 'k'  
grid on   

subplot(1,3,3)
hist(x,20,'r')

    



