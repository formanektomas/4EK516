
%% ADVANCED ECONOMETRICS
%
%  SIMULATE DATA FROM LINEAR OBSERVATION-DRIVEN LOCAL-LEVEL MODEL
%
%  Description: 
%  This code snippet shows how to simulate data from a  
%  linear observation-driven local-level (LL) model given by:
%
%  x(t) = mu(t) + epsilon(t)
%
%  mu(t+1) = omega + alpha (x(t) - mu(t)) + beta * mu(t)
%
%  where eps ~ NID(0,sigma_eps^2)  
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

    T=250;  % sample size

%% 2. Parameter Values

    omega = 1;      % intercept parameter in update equation
    alpha = 0.1;    % OD parameter in update equation
    beta = 0.98;    % autoregressive parameter un update equation
    sigma_eps = 0.1;  % standard error of innovations
    mu1 = omega/(1-beta); % define initial value for conditional expectation

%% 3. Generate Innovations

    epsilon = sigma_eps*randn(T,1); % generate a vector of T random normal 
                                % variables with variance sigma_eps^2

%% 4. Define Time Series Vector

    mu = zeros(T,1); % define vector of zeros of length T
    x = zeros(T,1); % define vector of zeros of length T
    
%% 5. Define Initialization for Time Series

    mu(1) = mu1;

%% 6. Generate Time Series

    for t=1:T % start recursion from t=2 to t=T
            
       x(t) = mu(t) +  epsilon(t); % observation equation
       
       mu(t+1) = omega + alpha * (x(t) - mu(t)) + beta * mu(t); % update equation
        
    end % end recursion
    
%% 7. Print Time Series in Command Window

[x(1:T),mu(1:T)] % display the values of x and volatility  
                         % side by side from t=1 to t=T

%% 8. Plot Data

figure(1)

plot(x(1:T),'k:')  % plot the time-series x in black 'k'

hold on % draw next plot in same graph

plot(mu(1:T),'r')  % plot volatility sigma in red 'r' 

legend('data: x','conditional expectation: mu')








