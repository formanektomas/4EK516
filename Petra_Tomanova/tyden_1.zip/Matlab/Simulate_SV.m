
%% ADVANCED ECONOMETRICS
%
%  SIMULATE DATA FROM A STOCHASTIC VOLATILITY MODEL
%
%  Description: 
%  This code snippet shows how to simulate data from a 
%  stochastic volatility (SV) model given by
%
%  x(t) = exp(sig(t)) * eps(t)
%
%  sig(t+1) = a + b * sig(t) + v(t)
%
%  where eps ~ NID(0,sigma_eps^2)  and  v ~ NID(0,sigma_v^2)
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

    T=1000;  % sample size

%% 2. Parameter Values

    a = 0;      % intercept parameter in update equation
    b = 0.99;     % autoregressive parameter in update equation
    sigma_v = 0.05;  % standard error of innovations in update equation
    sigma_eps = 0.1;  % standard error of innovations in observation equation
    sig1 = chi2rnd(1) %a/(1-b); % define initial value for conditional log volatility

%% 3. Generate Innovations

    v =  sigma_v*randn(T,1); % generate a vector of T random normal 
                                % variables with variance sigma_v^2

    epsilon = sigma_eps*randn(T,1); % generate a vector of T random normal 
                                % variables with variance sigma_eps^2

%% 4. Define Time Series Vector

    sig = zeros(T,1); % define vector of zeros of length T
    x = zeros(T,1); % define vector of zeros of length T
    
%% 5. Define Initialization for Time Series

    sig(1) = sig1;

%% 6. Generate Time Series

    for t=1:T % start recursion from t=2 to t=T
       
       sig(t+1) = a + b * sig(t) + v(t); %update equation
        
       x(t) = exp(sig(t)) * epsilon(t); % observation equation
        
    end % end recursion
    
%% 7. Print Time Series in Command Window

[x(1:T),exp(sig(1:T))] % display the values of x and volatility  
                         % side by side from t=1 to t=T

%% 8. Plot Data

figure(1)

subplot(2,1,1)    % plot goes on upper part of figure 1
plot(x(1:T),'k')  % plot the time-series x in black 'k'

subplot(2,1,2)           % plot goes on upper part of figure 1
plot(exp(sig(1:T)),'r')  % plot volatility sigma in red 'r' 




