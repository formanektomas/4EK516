# libraries
library(nloptr)

# load data
w = read.csv('C:/Users/Satan/Dropbox/doktorske/materialy_uceni/4EK516_Pokrocila_ekonometrie_2/seminars/seminar_6/wind_data.csv')
w = w$w

TT = length(w)

# criterion function
llik.OD = function(theta,w) {
  
  TT = length(w)
  
  alpha = theta[1]
  beta = theta[2]
  
  ## Filter r
  r = rep(NA,TT)
  r[1] = w[1] # initialization
  
  for (t in 1:(TT-1)) {
    r[t+1] = alpha * (w[t] - r[t]) + beta * r[t]
  }
  
  ## Calculate RE
  RE = sum(100 * (1 - (0.1^2 * (w - r)^2) / (1 + 0.1^2 * (w - r)^2)))
  
  return(-RE/TT)
}

# initial values
start.theta = c(0.5,1)

# optimization
opt.result = nloptr(x0 = start.theta, lb = c(1e-4, 1e-4), ub = c(Inf, Inf), eval_f = llik.OD, w = w,
                     opts = list(algorithm = 'NLOPT_LN_PRAXIS', xtol_rel = 0, maxeval = 1e8))
# estimated parameters
opt.theta = opt.result$solution
opt.theta
# likelihood
-opt.result$objective


## PLOTS

# no filter smoothing
r1 = c(w[1],rep(NA,TT-1))
for (t in 1:(TT-1)) {
  r1[t+1] = w[t]
}
plot(w, type = 'l')
lines(r1, col = 'red')

# factory setting
r2 = c(w[1],rep(NA,TT-1))
for (t in 1:(TT-1)) {
  r2[t+1] = 0.5 * (w[t] - r2[t]) + 1 * r2[t]
}
plot(w, type = 'l')
lines(r2, col = 'red')

# optimal setting
r3 = c(w[1],rep(NA,TT-1))
for (t in 1:(TT-1)) {
  r3[t+1] = opt.theta[1] * (w[t] - r3[t]) + opt.theta[2] * r3[t]
}
plot(w, type = 'l')
lines(r3, col = 'red')
