
      
%% ADVANCED ECONOMETRICS
%
%  COVERAGE OF VALUE-AT-RISK WITH GARCH(1,1)
%
%  Description:
%  This code snippet shows how to calculate and plot
%  the covarage of the value-at-risk (VaR).
%
%  Francisco Blasques 2017
%  Petra Tomanova 2020


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window

%% 1. Load Data

%% 1. Setup

      load stock_returns
      
%% 2. Optimization Options

      options = optimset('Display','iter',... %display iterations
                         'TolFun',1e-12,... % function value convergence criteria 
                         'TolX',1e-12,... % argument convergence criteria
                         'MaxIter',100); % maximum number of iterations    

%% 4. Initial Parameter Values
      
      omega_ini = 0.1;% initial value for omega
      alpha_ini = 0;  % initial value for alpha
      beta_ini = 0;   % initial value for beta
      
      theta_ini = [omega_ini,alpha_ini,beta_ini];
      
      
%% 5. Parameter Space Bounds
        
      lb=[0.0001,0,0];    % lower bound for theta
      ub=[100,100,100];   % upper bound for theta
      
      
%% 6. Optimize Log Likelihood Criterion
      
      % fmincon input:
      % (1) negative log likelihood function: - llik_fun_AR1()
      % (2) initial parameter: theta_ini
      % (3) parameter space bounds: lb & ub
      % (4) optimization setup: options
      %  Note: a number of parameter restriction are left empty with []

      % fmincon output:
      % (1) parameter estimates: theta_hat
      % (2) log likelihood function value at theta_hat: ls_val
      % (3) exit flag indicating (no) convergence: exitflag
      
      [theta_hat,llik_val,exitflag]=...
          fmincon(@(theta) - llik_fun_GARCH(x,theta),theta_ini,[],[],[],[],lb,ub,[],options);
      

%% 6. Obtain filtered volatility

T= length(x);
sig(1) = var(x);

    for t=1:T % start recursion from t=2 to t=T
      
        sig(t+1) = theta_hat(1) + theta_hat(2) * x(t)^2 + theta_hat(3) * sig(t);
     
    end

%% 5. Calculate VaR  

% a-VaR
a = 0.1; 

for t=1:T+1
    
    VaR10(t)= icdf('Normal',a,0,sqrt(sig(t)));
      
end


%% 6. Plot Data

figure(1)
subplot(3,1,1:2)
plot(x,'k')
xlim([0 1001])
hold on
plot(VaR10,'r')
title('returns and 10%-VaR')

subplot(3,1,3)
plot((x<VaR10(1:end-1)'))
title('hit variable')

%% 7. Hits

% total hits
Total_Hits = sum((x<VaR10(1:end-1)'))

% coverage (should be around 10 %)
Hits_Fraction = Total_Hits/T * 100

% Is the number close enough to 10 %?
[a*T - norminv(0.975) * sqrt(T*a*(1-a)) a*T + norminv(0.975) * sqrt(T*a*(1-a))]






      