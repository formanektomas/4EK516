
%% ADVANCED ECONOMETRICS
%
%  CONDITIONAL PROBABILITY OF NLAR(1)
%
%  Description: 
%  This code snippet shows how to numerically calculate the conditional
%  probability of a certain event occuring h-steps ahead given an NLAR(1) model.
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

    h = 3; % Set steps ahead
    N = 10000; % Set number of draws

%% 2. Parameter Values

    x_T = 0.2; % Set value of x_T

%% 3. Generate Innovations
    
    eps_T1 = 0.1*randn(h,N); % Generate N values of epsilon_T+1

%% 4. Calculate N values of x_T+h

    x(1,:) = x_T*ones(1,N);
   
    for t=1:h
        x(t+1,:) = tanh(0.9*x(t,:) + eps_T1(t,:)); 
    end

%% 5. Calculate P(x_T+1>0.4)
   
    P04 = (1/N)*sum(x(h+1,:)>0.4);
    
%% 6. Print result

    P04
 

