
%% ADVANCED ECONOMETRICS
%
%  NUMERICAL IMPULSE RESPONSE FUNCTION FOR AR(1)
%
%  Description: 
%  This code snippet shows how to numerically calculate an 
%  impulse response function (IRF) and respective confidence bounds 
%  for an AR(1) model.
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

N = 10000; % Set number of draws

%% 2. Parameter Values

s = 3; % Set schock time s
x0 = 0.2; % Set origin value
e = -1; % Set shock size e
h = 7; % Set steps ahead for IRF

%% 3. Generate Innovations

eps = 0.1*randn(s+h,N); % Generate innovation values
eps(1:s-1,:)=0; % Set shocks to zero for t<s
eps(s,:)=e; % Set shocks to e for t=s

%% 4. Generate IRF

x(1:s-1,:) = x0*ones(s-1,N); % Set time-series to x for t<s

x(s,:) = (x0+e)*ones(1,N); % Set time-series to x+e for t=s
   
for t=s+1:s+h
    x(t,:) = tanh(0.9*x(t-1,:) + eps(t,:)); 
end

% Calculate point forecasts (conditional mean) and confidence bounds (5 and
% 95 percentiles) recursively 
for t=1:s+h
    x_hat(t) = mean(x(t,:));
    upper_bound(t) = prctile(x(t,:),95);
    lower_bound(t) = prctile(x(t,:),05);
end

%% 5. Plot Data

plot(upper_bound,'r')
hold on
plot(lower_bound,'r')
hold on
plot(x_hat,'k')
set(gca,'FontSize',16,'XTickLabel',{'s-2','s-1','s','s+1','s+2','s+3','s+4','s+5','s+6','s+7','s+8','s+9','s+10'})
ylim([-1.2 0.4])
grid on







