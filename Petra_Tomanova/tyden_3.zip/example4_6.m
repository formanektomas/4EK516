clear all   %clear workspace
clc         %clear command window 

x = importdata('car_crash_data.mat');

T = size(x,2);
k = size(x,1);
s = zeros(k,T);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% raw data is not an option: s(t) = x(t)
for i = 1:k
    for t = 1:T
        s(i, t)= x(i, t);
    end
end

% deployments
reshape(sum(s < -1,2) > 1,[5,2])

for i = 1:k
   subplot(2,5,i);
   plot(x(i,:),'k');
   ylim([-1.1 0.4])
   xlim([1 T])
   hold on;
   plot(s(i,:),'r');
   hold on;
   line([0,T], [-1,-1], 'Color', 'blue', 'LineStyle', '--', 'LineWidth', 0.7);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% raw data is not an option: s(t) = 10 * x(t)
for i = 1:k
    for t = 1:T
        s(i, t)= 10 * x(i, t);
    end
end

% deployments
reshape(sum(s < -1,2) > 1,[5,2])

for i = 1:k
   subplot(2,5,i);
   plot(x(i,:),'k');
   ylim([-1.1 0.4])
   xlim([1 T])
   hold on;
   plot(s(i,:),'r');
   hold on;
   line([0,T], [-1,-1], 'Color', 'blue', 'LineStyle', '--', 'LineWidth', 0.7);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% observation driven filter: s(t) = -0.0135 + 0.4 * x(t-1) + 0.975 * s(t-1)
for i = 1:k
    for t = 2:T
        s(i, t) = -0.0135 + 0.4 * x(i, t-1) + 0.975 * s(i, t-1);
    end
end

% deployments
reshape(sum(s < -1,2) > 1,[5,2])

for i = 1:k
   subplot(2,5,i);
   plot(x(i,:),'k');
   ylim([-1.1 0.4])
   xlim([1 T])
   hold on;
   plot(s(i,:),'r');
   hold on;
   line([0,T], [-1,-1], 'Color', 'blue', 'LineStyle', '--', 'LineWidth', 0.7);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% observation driven filter: s(t) = -0.0135 + 0.8 * x(t-1) + 0.975 * s(t-1)
for i = 1:k
    for t = 2:T
        s(i, t) = -0.0135 + 0.8 * x(i, t-1) + 0.975 * s(i, t-1);
    end
end

% deployments
reshape(sum(s < -1,2) > 1,[5,2])

for i = 1:k
   subplot(2,5,i);
   plot(x(i,:),'k');
   ylim([-1.1 0.4])
   xlim([1 T])
   hold on;
   plot(s(i,:),'r');
   hold on;
   line([0,T], [-1,-1], 'Color', 'blue', 'LineStyle', '--', 'LineWidth', 0.7);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% observation driven filter: s(t) = -0.0135 + 0.5 * x(t-1) + 0.975 * s(t-1)
for i = 1:k
    for t = 2:T
        s(i, t) = -0.0135 + 0.5 * x(i, t-1) + 0.975 * s(i, t-1);
    end
end

% deployments
reshape(sum(s < -1,2) > 1,[5,2])

for i = 1:k
   subplot(2,5,i);
   plot(x(i,:),'k');
   ylim([-1.1 0.4])
   xlim([1 T])
   hold on;
   plot(s(i,:),'r');
   hold on;
   line([0,T], [-1,-1], 'Color', 'blue', 'LineStyle', '--', 'LineWidth', 0.7);
end

