
%% ADVANCED ECONOMETRICS
%
%  NUMERICAL FORECAST FROM NLAR(1)
%
%  Description:
%  This code snippet shows how to numerically obtain point
%  forecasts and respective confidence bounds for an NLAR(1) model.
%
%  Francisco Blasques 2016


%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window

%% 1. Setup


h = 20; % Set steps ahead

N = 10000; % Set number of draws


%% 2. Parameter Values

x_T = 1.2; % Set value of x_T


%% 3. Generate Innovations

eps_T1 = 0.1*randn(h,N); % Generate N values of epsilon_T+1


%% 4. Generate Forecasts

x(1,:) = x_T*ones(1,N); % Calculate N values of x_T+3

for t=1:h
    x(t+1,:) = tanh(0.9*x(t,:) + eps_T1(t,:));
end

% Calculate point forecasts (conditional mean) and confidence bounds (5 and
% 95 percentiles) recursively
x_hat(1) = x_T;
upper_bound(1)= x_T;
lower_bound(1)= x_T;
for t=1:h
    x_hat(t+1) = mean(x(t+1,:));
    upper_bound(t+1) = prctile(x(t+1,:),99);
    lower_bound(t+1) = prctile(x(t+1,:),01);
end

%% 5. Plot Data

plot(x_hat,'k')
hold on
plot(upper_bound,'r')
hold on
plot(lower_bound,'r')
set(gca,'FontSize',16,'XTickLabel',{'T','T+1','T+2','T+3','T+4','T+5','T+6','T+7','T+8','T+9','T+10'})
grid on






  N = 10000; % Set number of draws

%% 2. Parameter Values

    x_T = 0.2; % Set value of x_T

%% 3. Generate Innovations
    
    eps_T1 = 0.1*randn(1,N); % Generate N values of epsilon_T+1

%% 4. Calculate N values of x_T+h

    x_T1 = tanh(0.9*x_T + eps_T1); 

        
%% 5. Calculate P(x_T+1>0.4)
   
    P04 = (1/N)*sum(x_T1>0.4);
    
%% 6. Print result

    P04 
 

