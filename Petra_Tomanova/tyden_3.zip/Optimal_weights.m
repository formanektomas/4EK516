%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Portfolio optimization     %
%     Petra Tomanova             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% define variables
syms k mu1 mu2 sig1 sig2 sig12

% define function to be maximized 
fun = (k * mu1 + (1-k) * mu2) / sqrt(k^2 * sig1 + (1-k)^2 * sig2 + 2 * k * (1-k) * sig12)

% define equation to be solved
eq = simplify(diff(fun,k)) == 0

% solve the equation for k
solve(eq,k)