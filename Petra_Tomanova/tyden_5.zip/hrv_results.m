

%% 00. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 0. Obtain data

load hrv_data.mat



x=[hrv1,hrv2];


%% 1. estimate univariate GARCH for each of the series


%% 1a. Optimization Options

      options = optimset('Display','iter',... %display iterations
                         'TolFun',1e-12,... % function value convergence criteria 
                         'TolX',1e-12,... % argument convergence criteria
                         'MaxIter',500); % maximum number of iterations    

%% 1b. Initial Parameter values for the optimization
      

      omega_ini = 0.1;% initial value for omega
      alpha_ini = 0.2;  % initial value for alpha
      beta_ini = 0.7;   % initial value for beta
      
      theta_ini = [omega_ini,alpha_ini,beta_ini];
      
%% 1c. Parameter Space Bounds
        
      lb=[0.00000001,0,0];    % lower bound for theta
      ub=[100,1,1];   % upper bound for theta
      
%% 1d. Optimize univariate log-Likelihood functions
   
% Estimate a univariate GARCH(1,1) for x(:,1)

     [theta_hat1,llik_val1,exitflag1]=...
          fmincon(@(theta) - llik_fun_GARCH(x(:,1),theta),theta_ini,[],[],[],[],lb,ub,[],options);
      
% Estimate a univariate GARCH(1,1) for x(:,2)

    [theta_hat2,llik_val2,exitflag2]=...
          fmincon(@(theta) - llik_fun_GARCH(x(:,2),theta),theta_ini,[],[],[],[],lb,ub,[],options);
      
      
      

subplot(2,1,1)
plot(hrv1,'k')
grid minor
title('HRV series 1')

subplot(2,1,2)
plot(hrv2,'k')
grid minor
title('HRV series 2')

     
theta_hat1

theta_hat2