clear all   %clear workspace
clc         %clear command window 

% settings
N = 1000000;
x_T = 0.039;
sigma_epsilon1 = 0.0219;
sigma_epsilon2 = 0.0221;

%%%%%%%% AR(1) %%%%%%%%%%
% conditional distribution
mu.c = 0.00081 + 0.967 * x_T;
normcdf(0,mu.c,sigma_epsilon1)
1 - normcdf(0.05,mu.c,sigma_epsilon1)

%%%%%%%% SESTAR %%%%%%%%%%
% conditional distribution
mu.c = 0.00082 + g * x_T;
normcdf(0,mu.c,sigma_epsilon2)
1 - normcdf(0.05,mu.c,sigma_epsilon1)

%%%%%%%% Simulations %%%%%%%%%%
epsilon1 = randn(1, N) * sigma_epsilon1;
epsilon2 = randn(1, N) * sigma_epsilon2;

x_T1_AR = 0.00081 + 0.967 * x_T * ones(1,N) + epsilon1;

g = 0.48 + (0.51 / (1 + exp(198 * x_T)))
x_T1_SESTAR = 0.00082 + g * x_T * ones(1,N) + epsilon1;

P_fall_AR = (1 / N) * sum(x_T1_AR < 0);
P_fall_SESTAR = (1 / N) * sum(x_T1_SESTAR < 0);

P_fall_AR
P_fall_SESTAR




