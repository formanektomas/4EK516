%% Example 4.12
% Crude oil production forecast

%% Clean enviroment
clear all
clc

%% Set parameters
N = 10000;
x_t = 0.039;
sigma_epsilon1 = 0.0219;
sigma_epsilon2 = 0.0221;
h = 4;

%% Generate Innovations
epsilon1 = randn(h, N) * sigma_epsilon1;
epsilon2 = randn(h, N) * sigma_epsilon2;

%% generate Forecasts
x_AR(1,:) = x_t * ones(1, N);
x_SESTAR(1,:) = x_t * ones(1, N);

for t = 1:h
    x_AR(t+1, :) = 0.00081 + 0.967 * x_AR(t, :) + epsilon1(t, :);
    
    g = 0.48 + (0.51 ./ (1 + exp(198 * x_SESTAR(t,:))));
    x_SESTAR(t+1, :) = 0.00082 + g .* x_SESTAR(t, :) + epsilon2(t, :);
end

%% Calculate means and bounds
x_hat_AR(1) = x_t;
upper_bound_AR(1)= x_t;
lower_bound_AR(1)= x_t;
for t=1:h
    x_hat_AR(t+1) = mean(x_AR(t+1,:));
    upper_bound_AR(t+1) = prctile(x_AR(t+1,:),95);
    lower_bound_AR(t+1) = prctile(x_AR(t+1,:),05);
end

x_hat_SESTAR(1) = x_t;
upper_bound_SESTAR(1)= x_t;
lower_bound_SESTAR(1)= x_t;
for t=1:h
    x_hat_SESTAR(t+1) = mean(x_SESTAR(t+1,:));
    upper_bound_SESTAR(t+1) = prctile(x_SESTAR(t+1,:),95);
    lower_bound_SESTAR(t+1) = prctile(x_SESTAR(t+1,:),05);
end

%% Plot Forecasts
subplot(1,2,1)
plot(x_hat_AR,'k')
hold on
plot(upper_bound_AR,'r')
hold on
plot(lower_bound_AR,'r')
ylim([-0.1 0.15])
%xticklabels({'T','T+1','T+2','T+3','T+4'})
grid on

subplot(1,2,2)
plot(x_hat_SESTAR,'k')
hold on
plot(upper_bound_SESTAR,'r')
hold on
plot(lower_bound_SESTAR,'r')
ylim([-0.1 0.15])
%xticklabels({'T','T+1','T+2','T+3','T+4'})
grid on