## 0. Clean Workspace and Command Window

rm(list = ls())   # clear envirnment     

## 1. Setup

N = 250  # sample size

## 2. Parameter Values

omega = 0.10     # intercept parameter in update equation
alpha = 0.05     # OD parameter in update equation
beta =  0.94     # autoregressive parameter in update equation
sig1 = 11 # omega/(1-alpha-beta)     # initial values for conditional volatility

## 3. Generate Innovations

epsilon = rnorm(N) # generate a vector of T random normal 
# variables with variance sigma_eps^2

## 4. Define Time Series Vector

sig = rep(0,N) # define vector of zeros of length T
x = rep(0,N) # define vector of zeros of length T

## 5. Define Initialization for Time Series

sig[1] = sig1

## 6. Generate Time Series

for (t in 1:N) { # start recursion from t=2 to t=T
  
  x[t] = sqrt(sig[t]) * epsilon[t] # observation equation
  sig[t+1] = omega + alpha * x[t]^2 + beta * sig[t] # update equation
  
} # end recursion

plot(x, type="l") 

## 7. filtered volatility for various initialisations
sigma = data.frame(sig.1 = rep(NA,N), sig.2 = rep(NA,N), sig.3 = rep(NA,N), sig.4 = rep(NA,N),
                   sig.true = sig[1:N])
sigma[1,1:4] = c(5,10,15,var(x))

for (i in 1:4) {
  for (t in 1:(N-1)) { # start recursion from t=2 to t=T
    sigma[t+1,i] = omega + alpha * x[t]^2 + beta * sigma[t,i] # update equation
  }
}

## 8. Plot Data

library(reshape2)
library(ggplot2)
library(gridExtra)

dfp = melt(sigma)
dfp$x = rep(1:N,5)

ggplot(dfp, aes(x = x, y = value)) + 
  geom_line(aes(color = variable)) +
  theme(axis.title.x=element_blank(), axis.title.y=element_blank()) 


