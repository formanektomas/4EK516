
%% Example 4.15
% Impulse response function

%% 0. Clean Workspace and Command Window

clear all   %clear workspace
clc         %clear command window     

%% 1. Setup

N = 10000; % Set number of draws

%% 2. Parameter Values

s = 3; % Set schock time s
x0 = -0.03; % Set origin value
e = 0.03; % Set shock size e
h = 5; % Set steps ahead for IRF
z0= 0;

%% 3. Generate Innovations

eps = 0.0032 * randn(s+h,N); % Generate innovation values
eps(1:s-1,:)=0; % Set shocks to zero for t<s
eps(s,:)=e; % Set shocks to e for t=s

%% 4. Generate IRF

x(1:s-1,:) = x0*ones(s-1,N); % Set time-series to x for t<s
x(s,:) = (x0+e)*ones(1,N); % Set time-series to x+e for t=s
z(1:s - 1,:)= z0 * ones(s - 1, N);
z(s, :) = (z0 + e) * ones(1, N);

for t= s + 1 : s + h
    g= 0.7 / (1 + exp(50.1 * x(t - 1)));
    x(t,:) = 0.002 + 0.92 * x(t - 1) + g * z(t - 1)+ eps(t, :); 
end

% Calculate point forecasts (conditional mean) and confidence bounds (5 and
% 95 percentiles) recursively 
for t=1:s+h
    x_hat(t) = mean(x(t,:));
    upper_bound(t) = prctile(x(t,:),95);
    lower_bound(t) = prctile(x(t,:),05);
end

%% 5. Plot Data

plot(upper_bound,'r')
hold on
plot(lower_bound,'r')
hold on
plot(x_hat,'k')
% set(gca,'FontSize',16,'XTickLabel',{'s-2','s-1','s','s+1','s+2','s+3','s+4','s+5','s+6','s+7','s+8','s+9','s+10'})
grid on







