
## 0. Clean Workspace and Command Window
rm(list = ls())   # clear envirnment    

## 1. load data
x = read.csv('C:/Users/Satan/Dropbox/doktorske/materialy_uceni/4EK516_Pokrocila_ekonometrie_2/seminars/seminar_2/vol_data.csv',
             header = F)
x = as.vector(x$V1)

## 2. Parameter Values
alpha = 0.1
beta = 0.95
delta = 0.2
lenX = length(x)

## 3. Define Time Series Vector
sig2G = rep(0,lenX)
sig2rG = rep(0,lenX)

## 4. Generate Time Series
for (t in 2:lenX){
  sig2G[t]= alpha * x[t]^2 + beta * sig2G[t-1]
  sig2rG[t]= delta^(-1) * alpha * tanh(delta * x[t-1]^2) + beta * sig2rG[t-1]
}

## 5. Plot
plot(x, type = 'l', ylim = c(-10,20))
lines(sig2G, col = 'red')
lines(sig2rG, col = 'blue')

## 7. News Impact Curves
x_T = seq(-5,5,0.1)

response1 = alpha * x_T^2
response2 = delta^(-1) * alpha * tanh(delta * x_T^2)

plot(x_T,response1,type = 'l', col = 'red')
lines(x_T,response2,col = 'blue')
