## RUGARCH package
library(rugarch)

# datasets
data(sp500ret)
data(dji30ret)

# fit Gaussian GARCH(1,1) with mean 
fit = ugarchfit(ugarchspec(distribution.model = "norm",mean.model = list(armaOrder = c(0,0))), sp500ret)
# fit Students' GARCH(1,1)-t with mean 
fitt = ugarchfit(ugarchspec(distribution.model = "std",mean.model = list(armaOrder = c(0,0))), sp500ret)

# print summary from fitted models
show(fit)
show(fitt)

# plot both fits
plot(sp500ret$SP500RET, type = 'l')
lines(fit@fit$sigma, col = 'red')
lines(fitt@fit$sigma, col = 'green')

# fit Gaussian GARCH(1,1) without mean 
fit.nomean = ugarchfit(ugarchspec(distribution.model = "norm",mean.model = list(armaOrder = c(0,0)),
                           fixed.pars=list(mu=0)), sp500ret)


## FGARCH package
library(fGarch)

# fit Gaussian GARCH(1,1) with mean 
gfit.fg <- garchFit(data=sp500ret, cond.dist="norm")
# fit Students' GARCH(1,1)-t with mean 
gfit.fg.t <- garchFit(data=sp500ret, cond.dist="std")

# print summary from fitted models
summary(gfit.fg)
summary(gfit.fg.t)

## TSERIES package
library(tseries)

# fit Gaussian GARCH(1,1) without mean 
gfit.ts <- garch(sp500ret)

# print summary from fitted models
summary(gfit.ts)


## compare coefficients from standard GARCH(1,1)
tab = cbind(data.frame(round(coef(fit),4)),
      data.frame(round(coef(gfit.fg),4)),
      data.frame(c(NA,round(coef(fit.nomean)[2:4],4))),
      data.frame(c(NA,round(coef(gfit.ts),4))))
colnames(tab) = c('rugarch','fGarch','rugarch(no mean)','tseries')
tab


## own estimation
library(nloptr)
# nloptr(x0 = ?, lb = ?, ub = ?, eval_f = ?, y = ?,
#                     opts = list(algorithm = 'NLOPT_LN_PRAXIS', xtol_rel = 0, maxeval = 1e8))


